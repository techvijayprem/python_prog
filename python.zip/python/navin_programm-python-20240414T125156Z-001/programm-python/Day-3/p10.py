s2="rahul "
s1="rahul is a good boy"
if(s2 in s1):
    print("the string 2 is preseint in string 1")
else:
    print("The string 2 is not present in string 1")