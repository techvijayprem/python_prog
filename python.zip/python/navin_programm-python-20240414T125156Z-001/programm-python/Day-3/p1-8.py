#p1
s1='''I like “Python Programming” very much
It is my favorite subject'''
print(s1)
for i in range(0,len(s1)):
    print(s1[i],i)
#p2
print(s1[28:37])
#p3
print(s1[-5:])
#p4
print(s1[s1.find("\n"):])
#p5
print(s1[len(s1):0:-1])
#p6
s2="hello "
s3="rahul"
print(s2+s3)
#p7
s4=input("Enter the string:- ")
n1=eval(input("Enter the number :- "))
print(3*s4);
#p8
c=input("enter the character :- ")
if(c in s4):
    print("the character is present in the string ")
else:
    print("The character is not present in the string ")
#p9
