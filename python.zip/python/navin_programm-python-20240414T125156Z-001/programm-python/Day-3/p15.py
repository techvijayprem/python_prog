s1="hello good morning"
s2=""
for i in s1:
    if(i=='o'):
        s2+='@'
    else:
         s2+=i
print(s2)