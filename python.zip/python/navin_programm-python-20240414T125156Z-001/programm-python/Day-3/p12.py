s2="rahul"
s1="rahul is a good boy"
if(s2 in s1):
    print("the s2 is present ",s1.count(s2)," number of time")
else:
    print("The string 2 is not present in string 1")