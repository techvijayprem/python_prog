s1=input("Enter the string :- ");

count=0
for  i in range(0,len(s1)):
    if(s1[i] in 'aeiouAEIOU'):
        print(s1[i]," - ",i)
        count=count+1
print("The numbre of vowels in string",count)