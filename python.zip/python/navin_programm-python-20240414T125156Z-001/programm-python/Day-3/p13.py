s1=input("Enter the string :- ");
s1=s1.lower();
count=0
for  i in s1:
    if(i>='a' and i<='z'):
        count=count+1
print("The number of words are",count)