s1='''I like “Python Programming” very much
It is my favorite subject'''



while(True):
    print("\na.length\nb.upper case\nc.lower case\nd.capitalization\ne.split\nEnter the choice ")
    ch=input();
    if(ch=='a'):
        print(len(s1))
    elif(ch=='b'):
        print(s1.upper());
    elif(ch=='c'):
        print(s1.lower());
    elif(ch=='d'):
        print(s1.capitalize())
    elif(ch=='e'):
        print(s1.split())
    elif(ch=='f'):
        break
    else:
        print("you enter wromg choice!")