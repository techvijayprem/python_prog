s2="rahul"
s1="rahul is a good boy"
if(s2 in s1):
    print("the s2 first character is ",s2[0],"the last occurence is ",s2[-1])
else:
    print("The string 2 is not present in string 1")