#p9
t1=()
name=input("Enter the name :- ")

hobby=()
num=eval(input("Enter the number of hobby :- "))
for i in range(num):
    val=input("Enter the hobby :- ")
    hobby+=(val,)
num=eval(input("Enter the number of friends :- "))
friends=()
for i in range(num):
    val=input("Enter the friends :- ")
    friends+=(val,)
degree=input("Enter the degree :- ")


t4=(name,hobby,friends,degree)

print(t4)

#p10

print("a.name\nb.hobby\nc.friends\nd.degree")
ch=input("Enter the choice :- ")
if(ch=='a'):
    search=input("Enter the name :- ")
    if search in t4:
        print("The name is found! on the posetion ",0)
    else :
        print("The name is not found!")
elif(ch=='b'):
    search=input("Enter the hobby :- ")
    if search in t4[1]:
        print("The hobby is found!")
        
        for i in range(len(t4[1])):
            if t4[1][i]==search:
                print("The postion is ",i)
                
    else :
        print("The hobby is not found!")
elif(ch=='c'):
    search=input("Enter the friends :- ")
    if search in t4[2]:
        print("The friends is found!")
        for i in range(len(t4[1])):
            if t4[2][i]==search:
                print("The postion is ",i)
    else :
        print("The friends is not found!")
elif(ch=='d'):
    search=input("Enter the degree :- ")
    if search in t4:
        print("The friends is degree!")
    else :
        print("The friends is not degree!")
else:
    print("you enter the wrong choice ")
    
    