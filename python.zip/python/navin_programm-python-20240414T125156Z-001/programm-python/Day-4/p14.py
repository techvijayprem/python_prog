str1=input("Enter the string 1:- ")
t1=('a','e','i','o','u','A','E','I','O','U')
count=0
for i in str1:
    if i in t1:
        print(i)
        count+=1
print("The totoal vowal is :- ",count)
