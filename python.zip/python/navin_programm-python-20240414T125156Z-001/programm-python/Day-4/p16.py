print("Enter the city of Gujrat :- ")
t1=()
for i in range(3):
    val=input()
    t1+=(val,)
print("The reverse name is :- ")
for i in t1:
    print(i[len(i):0:-1])
