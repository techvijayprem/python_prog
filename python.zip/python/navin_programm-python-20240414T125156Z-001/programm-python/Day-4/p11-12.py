#p11
odd=()
even=()
t1=()
for i in range(10):
    val=int(input("Enter the number :- "))
    if(val %2==0):
        even+=(val,)
    else:
        odd+=(val,)
    t1+=(val,)

print(odd)
print(even)

for i in range(len(t1),0,-1):
    print(i)