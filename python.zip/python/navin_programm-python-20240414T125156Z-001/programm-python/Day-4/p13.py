str1=input("Enter the string 1:- ")
str2=""
for i in str1:
    if(i=='o'):
        str2+="@"
    else:
        str2+=i
print(str2)