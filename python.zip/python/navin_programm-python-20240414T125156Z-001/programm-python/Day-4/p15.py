t1=()
for i in range(10):
    val=int(input("Enter the number :- "))
   
    t1+=(val,)
maxnum=t1[0]
minnum=t1[0]
for i in t1:
    if i >maxnum:
        maxnum=i
    if i <minnum:
        minnum=i
print("the max num is :- ",maxnum,"The min num is ",minnum)