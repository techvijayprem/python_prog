#p1
t1=("Rahul","Pandey","Vijaykumar")
#p2
t2=(50,50,45,40,42)
#p5
ans =0 
for i in t2:
    ans+=i
print("The sum is :- ",ans)

#p4
t3=(t1,t2)

print(t3)

#p5
find=int(input("Enter the name to search :- "))
flag = True
if find in  t3[1]:   
        print("The element is found!")
else:
        print("The elemenmt is not found!")
     
#p6
fruit=("Apple","banana","mango","orange")
find=input("Enter the fruit name :-  ")
if find in fruit:
    print("The fruit found")
else:
    print("The element  not found !")





