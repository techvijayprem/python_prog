print("Enter the city of Gujrat :- ")
t1=()
for i in range(3):
    val=input()
    t1+=(val,)
print(t1)

#p8

for i in t1:
    count=0
    for j in i:
        count+=1
    print(i," => ",count)
    
for i in t1:
    
    print(i," => ",len(i))

