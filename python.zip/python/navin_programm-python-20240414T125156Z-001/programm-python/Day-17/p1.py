'''
Exercise	1.	Create a MySQL database table called Tournament. Use exception handling while creating a database table.
2.	Having fields like Name, Age, Sport_Play, NoOfTournaments
3.	After inserting data in the table, write a menu driven program to 
a.	Display sport wise no. of players (sports name  -  count of players)
b.	Display player’s details for a specific sport.
c.	Update the tournament field (increment by 1) for a user specified player (when he has played match)
d.	Search players’ detail by their name.
e.	Delete a record of specific player
4.	Take the DB table backup in the binary file. (Use Pickle.dump())
5.	Delete all the records from the above table
6.	Reload the data from text file. (Use Pickle.load())


'''
import sqlite3 as db
import pickle
con=db.connect("mydatabase")
cur=con.cursor()
try:
    #cur.execute("create table Tournament([name] varchar(20),[age] number,[sport_play] varchar(50),[no] number)")
    cur.execute("insert into Tournament values('rahul',21,'chess',2)")
    cur.execute("insert into Tournament values('aanshi',20,'codename',2)")
    cur.execute("insert into Tournament values('gaurang',21,'chess',1)")
    cur.execute("insert into Tournament values('khushali',21,'ludo',3)")
    def noOfplayer():
        ans=cur.execute("select sport_play,count(*) from Tournament group by sport_play")
        for i in ans:
            print(i)
    def playerDetailsBysport():
        sport=input("Enter the sport name :- ")
        tup=(sport)
        ans=cur.execute("select * from Tournament where sport_play='%s'"%tup)
        for i in ans:
            print(i)
    def playerDetailsByname():
        name=input("Enter the name :- ")
        tup=(name)
        ans=cur.execute("select * from Tournament where name='%s'"%tup)
        for i in ans:
            print(i)
    def update():
        name=input("Enter the name :- ")
        tup=(name)
        cur.execute("update Tournament set no=no+1 where name='%s'"%tup)
        ans=cur.execute("select * from Tournament")
        for i in ans:
            print(i)
    def backup():
        cur.execute("select * from Tournament")
        ans=cur.fetchall()
        with open('abcd.bin','wb') as f:
            pickle.dump(ans, f)
        with open('abcd.bin','rb') as f1:  
             obj=pickle.load(f1)
             print(obj)
        
    def delete():
        cur.execute("delete from Tournament")
        cur.execute("select * from Tournament")
        ans=cur.fetchall()
        print(ans)
        
        
        
    while 1:
        print('''
              1.no of player
              2.player detils by sports
              3.update
              4.player detils by name
              5.backup
             
              enter any number for exits
              ''')
        ch=int(input("enter the choice ;- "))
        if ch==1:
            noOfplayer()
        elif ch==2:
            playerDetailsBysport()
        elif ch==3:
            update()
        elif ch==4:
            playerDetailsByname()
        elif ch==5:
            backup()
    
        else:
            break
            
except:
    print("Error hai")
