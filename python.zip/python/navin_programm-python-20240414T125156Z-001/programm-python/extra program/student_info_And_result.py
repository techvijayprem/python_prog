num=int(input("Enter the number of student :- "))
student=()
result=()
for i in range(num):
    name=input("Enter the name :- ")
    marks=()
    for j in range(3):
        val=eval(input("Enter the marks of subject :- "))
        marks+=(val,)
    total=sum(marks)
    per=(total/3)
    student+=((name,marks),)
    result+=(((name),total,per),)

print(student)
print(result)  

name=input("Enter the name of student :- ")
flag=True
for i in result:
    if name in i:
        print(i)
        flag=False
if flag:
    print("Name not found!")    