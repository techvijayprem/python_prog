# if program 
n1=eval(input("Enter num1 :-"))
n2=eval(input("Enter num2 :-"))
n3=eval(input("Enter num3 :-"))
if(n1>n2 and n1>n3):
    print("num1 is greater then num2 and num3")
elif(n2>n1 and n2>n3):
    print("num2 is greater then num1 and num4")
else: 
    print("num3 is greater then num2 and num1")