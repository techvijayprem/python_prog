#p-14
stu={}
for i in range(2):
    mark=[]
    rollno=input("Enter the rollno:-")
    for i in range(6):
       mark1=int(input("Enter the marks :-"))
       mark+=[mark1,]
    stu[rollno]=mark
maxmin={}
for i in stu:
    minmark=600
    maxmark=0
    for j in stu[i]:
        if j<minmark:
            minmark=j
        if j>maxmark:
            maxmark=j
    maxmin[i]=[minmark,maxmark];
        
print(maxmin)