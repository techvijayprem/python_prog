#p-11
stu={}
for i in range(2):
    mark=[]
    rollno=input("Enter the rollno:-")
    for i in range(5):
       mark1=int(input("Enter the marks :-"))
       mark+=[mark1,]
    stu[rollno]=mark
#p-12
result={}

for i in stu:
    total=sum(stu[i])
    print(stu[i])
    per=total/5
    grade=''
    if per>90:
        grade='A'
    elif per<=90 and per>70:
        grade='B'
    elif per<=70 and per>50:
        grade='C'
    else:
        grade='D'
    result[i]=(total,per,grade)
    
print(result)  


#p-13
maxmark=result[rollno][0]
minind=rollno
for i in result:
    if result[i][0]>maxmark:
        maxmark=result[i][0]
        maxind=i
print("the max total is :- ",maxmark,"the rollno is ",maxind)
    

