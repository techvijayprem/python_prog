#p-15
fru={}
for i in range(2):
    
    fruit=input("Enter the fruit:-")
    buy=int(input("Enter the buying price :- "))
    sel=int(input("Enter the selling price:- "))
    fru[fruit]=(buy,sel)
print(fru)
print("bying price is lesser then selling :- ")
for i in fru:
    if(fru[i][0]>fru[i][1]):
        print(i)
print("selling price is lesser then selling :- ")
for i in fru:
    if(fru[i][0]<fru[i][1]):
        print(i)
        