#p1
emp={}
for i in range(3):
    empid=input("Enter the empid:-")
    name=input("Enter the name :-")
    emp[empid]=name
print(emp)
#p2
print(len(emp))
#p3
print(emp.keys())
#p4
print(emp.values())
#p5-7
search=input("Enter empid :-")
if search in emp:
    print("The employe exist and the name is ",emp[search])
    emp[search]=input("Change the name  :-")
    print(emp)
else:
    print("The employe does not exist")
    emp[search]=input("Enter the name :-")
#p8
search=input("Enter empid  for delete :-")
if search in emp:
    del emp[search]
else:
    print("The employe does not exist")
    


