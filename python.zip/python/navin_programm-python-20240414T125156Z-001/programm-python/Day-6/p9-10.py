#p9
stu={}
for i in range(2):
    name=input("Enter the name:-")
    age=int(input("Enter the age :-"))
    degree=input("Enter the degree :-")
    fav=input("Fav subject :- ")
    stu[name]=[age,degree,fav]
print(stu)
#p10
mins=stu[name][0]
minkey=""
for i in stu:
    if stu[i][0]<mins:
        mins=stu[i][0]
        minkey=i
print("The yongest student is :- ",mins,stu[minkey],"name is ",minkey)
#p11

    