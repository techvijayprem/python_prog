import logging
try:
    a=2/0
except:
    logging.basicConfig(filename="a.txt",level=40)
    logging.error("Error-hai")
    
    
