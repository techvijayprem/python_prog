import sqlite3 as db
from datetime import datetime
con=db.connect('mydatabase')
cur=con.cursor()
def display():
    s='select*from employee'
    cur.execute(s)
    row=cur.fetchall()
    print(row)
#cur.execute('''create table employee([eno] number,[ename] varchar(50),[age] numbr,[salary] number,[obj] date)''')
def insert():
    eno=int(input("Enter the emp no :- "))
    ename=input("Enter the emp name :- ")
    age=int(input("Enter the age :- "))
    salary=int(input("Enter the salary :- "))
    dt=datetime.now()
    s = "insert into employee (eno,ename,age,salary,obj) values (?,?,?,?,?)"
    
    val=(eno,ename,age,salary,dt)
 
    cur.execute(s,val)
    display()
def update():
    eno=int(input("Enter the emp no :- "))
    tup=(eno)
    cur.execute("update employee set age=age+1 where eno='%s'"%tup)
    ans=cur.execute("select * from employee")
    for i in ans:
        print(i)
def delete():
    eno=int(input("Enter the emp no :- "))
    tup=(eno)
    cur.execute("delete from employee where eno='%s'"%tup)
    ans=cur.execute("select * from employee")
    for i in ans:
        print(i)
    
while 1:
    print('''
          1.insert
          2.update
          3.delete
          enter any nuber for exit
          ''')
    ch=int(input("Select the choice :- "))
    if(ch==1):
        insert()
    elif ch==2:
        update()
    elif ch==3:
        delete()
    else:
        break
        
    

