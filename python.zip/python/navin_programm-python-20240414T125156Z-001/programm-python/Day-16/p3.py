from datetime import datetime
dt=datetime
print(datetime.strftime(dt.now(), '%A'))
print(datetime.strftime(dt.now(), '%a'))
print(datetime.strftime(dt.now(), '%w'))
