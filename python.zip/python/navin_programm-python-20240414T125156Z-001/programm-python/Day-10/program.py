from functools import reduce
#p1
f=lambda *x:sum(x)/len(x)  if len(x)>0 else 0;
print(f(1,2,3,5))
print(f(2,3,4))
#p2
l1=[6, 5, 3, 9]  
l2=[0, 1, 7, 7] 

print(list(map(lambda x,y: x+y if x<y else x-y,l1,l2)))
#p3
l1=['Rahul','raj','ravi']
print(list(map(lambda x:x.upper(),l1)))

#p4
l1=[6.56773, 9.57668, 4.00914, 56.24241, 9.01344]
print(list(map(lambda x:(round(x),round(x,2)),l1)))

#p5
str1="Hello how are you?"
print(list(map(lambda x:{x:x.upper(),'len':len(x)},str1.split())))
#print(list(map(lambda x:dict(map(lambda a:{a:x.count(a) if a in 'aeiou'},x.split())),str1.split())))
print(list(map(lambda x:{x.upper():{i:x.count(i) for i in x if i in'aeiouAEIOU'},'len':len(x)},str1.split())))
#p6
l1=[6, 5, 3, 9]  
print(list(map(lambda x:x**2,l1)))

#p7
mark=[88, 92, 78, 95, 86]
print(list(map(lambda x:'A' if x>90 else 'B' if x<=90 and x>70 else 'C' if x<=70 and x>50 else 'D',mark)))

#p8
mark=[1,2,3,4,5]
total=reduce(lambda x,y:x+y,mark)
print(total)

#p9

total=reduce(lambda x,y:x*y,mark)
print(total)

#p10
total=reduce(lambda x,y:x if x>y else y,mark)
print(total)

#p11
l1=[[1, 2],[3,4],[5,6],[7,8]]
row=[]
colm=[]
for i in range(len(l1)):
    for j in range(len(l1[0])):
        if(j%2==0):
            row.append(l1[i][j])
        else:
            colm.append(l1[i][j])
print([row,colm])

#p12
def fact(i):
    if i<=1:
        return i
    return fact(i-1)+fact(i-2)
for i in range(1,5):
      print(fact(i))



