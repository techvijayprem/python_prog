import pandas as pd
word=[]
vovel=[]
letter=[]
with open('a.txt','r') as f:
    string=f.read()
    print(string)
    for i in string.split("\n"):
        word+=[len(i.split()),]
        vovel.append(len(list(filter(lambda x:x in 'aeiouAEIOU',list(i)))))
        print("->",i)
        letter.append(len(list(filter(lambda x:x!=" ",list(i)))))
      
df=pd.DataFrame([word,vovel,letter],columns=["word","letter","vovel"])   
print(df) 