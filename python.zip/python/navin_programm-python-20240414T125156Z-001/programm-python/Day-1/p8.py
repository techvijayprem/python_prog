#program 8 use input() print whith hello
name =input("Enter the name :- ")
print("Hello .. "+name)
