#program 2 use input()
name =input("Enter the name :- ")
print("your name is "+name)
