#program 14 fahrenheit to celcious
F=eval(input("Enter Fahrenheit  :-"))
C = (F - 32) / 1.8
print("The Celcious is ",C)

