#program 18 area of cube 
l=eval(input("Enter length :-"))
b=eval(input("Enter breath :-"))
h=eval(input("Enter height :-"))

print("The area of cube:-",(l*b*h))
