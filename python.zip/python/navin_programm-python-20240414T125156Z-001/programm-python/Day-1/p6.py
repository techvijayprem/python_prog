#program 6 quotient remender
num1 =eval(input("Enter the num1 :- "))
num2 =eval(input("Enter the num2 :- "))

print("The quotient is ",num1//num2)
print("The remender is ",num1%num2);
