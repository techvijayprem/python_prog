#Day 1-program 1
print("hello world")




