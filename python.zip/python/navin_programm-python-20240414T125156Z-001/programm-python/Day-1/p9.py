#program 9 use input() three time in one print
name =input("Enter the name :- ")
print(3*name)

