#program 12 area of tringle 
l=eval(input("Enter length :-"))
b=eval(input("Enter breath :-"))

print("The area of triangle:-",(l*b)/2)

