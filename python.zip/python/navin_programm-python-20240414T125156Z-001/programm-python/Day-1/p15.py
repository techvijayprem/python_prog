#program 15  celcious to fahrenheit
C=eval(input("Enter Celcious  :-"))
F = C*(9/5) + 32
print("The fahrenheit is ",F)