#program 16  meter to km
m=eval(input("Enter meter  :-"))
km=m/1000
print("The km is ",km)