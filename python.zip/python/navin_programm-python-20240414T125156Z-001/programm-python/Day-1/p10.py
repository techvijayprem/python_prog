#program 10 area of circle
r=eval(input("Enter the radious :-"))
print("The are of circle is ",3.14*r*r)