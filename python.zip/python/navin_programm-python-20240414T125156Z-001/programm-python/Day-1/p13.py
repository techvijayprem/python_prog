#program 13 swap variable
l=eval(input("Enter num1 :-"))
b=eval(input("Enter num2 :-"))

print("The swap before value:- ",l,b)
l,b=b,l
print("The swap after value:- ",l,b)

