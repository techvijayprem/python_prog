#program 17 area of rectangle 
l=eval(input("Enter length :-"))
b=eval(input("Enter breath :-"))

print("The area of rectangle:-",(l*b))