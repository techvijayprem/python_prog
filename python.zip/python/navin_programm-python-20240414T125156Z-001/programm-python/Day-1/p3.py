#program 3 use WAP take number value input()
num1 =eval(input("Enter the num1 :- "))
num2 =eval(input("Enter the num2 :- "))
ans=num1+num2
print(ans)
