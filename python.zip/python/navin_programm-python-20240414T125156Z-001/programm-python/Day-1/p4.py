#program 4 convert number into float
num1 =eval(input("Enter the num1 :- "))

print(float(num1))
