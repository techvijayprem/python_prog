#program 11 simple interest
n=eval(input("Enter number of year :-"))
r=eval(input("Enter rate of interst  :-"))
p=eval(input("Enter principal amount :-"))
print("The Simple interst is :-",(p*r*n)/100)

