#program 5 perform add sub mult div
num1 =eval(input("Enter the num1 :- "))
num2 =eval(input("Enter the num2 :- "))
print("The additon is :-",num1+num2)
print("The subtraction is :-",num1-num2)
print("The multiplication is :-",num1*num2)
print("The division is :-",num1/num2)

