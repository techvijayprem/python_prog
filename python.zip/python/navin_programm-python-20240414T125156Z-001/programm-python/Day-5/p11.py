l1=[i for i in range(1,10)]
max=l1[0]
min=l1[0]
for i in l1:
    if(i >max):
        max=i
    if(i<min):
        min=i
print("Max is :- ",max,"min is :- ",min)