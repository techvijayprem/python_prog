name=input("Enter the name:- ")
age=int(input("Enter the age:- "))
height=input("Enter the height:- ")
com=input("Enter the company name :-")
salray=input("Enter salray :- ")
l1=[name,age,height,com,salray]
print(l1)