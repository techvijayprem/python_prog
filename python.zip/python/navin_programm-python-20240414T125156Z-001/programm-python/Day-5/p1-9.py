#p1
l1=["rahul","anshi","rahul","manushri","manushri","gaurang"]
#p2
print(len(l1))
#p3
l1.append("kushali")
#p4
l1.sort()
print(l1)
#p5,6
name=input("Enter the name :- ")
if(name in l1):
    print(name," is present")
    print("total number of student is :-",l1.count(name))
    for i in range(len(l1)):
        if(l1[i]==name):
            print("the postion of first occurence is :- ",i)
            break
else:
    print(name," is absent")
#p7
print("The last student removed :-",l1.pop())
#p8
name=input("Enter the name to remove :- ")
print("The student removed :-",l1.remove(name))
print(l1)
#p9
while(name in l1):
    l1.remove(name)
print(l1)
#p15
for i in l1:
    if 'a' in i:
        print(i)
