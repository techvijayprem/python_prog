l1=["rahul","anshi","anshi","rahul",1,2,3,4]
l2=[i for i in l1 if type(i)==int]
print(l2)

l3=[i for i in l1 if l1.count(i)==1]
print(l3)