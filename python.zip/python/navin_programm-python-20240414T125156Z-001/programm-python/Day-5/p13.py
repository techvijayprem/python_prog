num=int(input("Enter the number :- "))
final=[]
for i in range(num):
    temp=[]
    name=input("etner the name :- ")
    age=int(input("Enter the age :- "))
    salary=int(input("Enter the salary :- "))
    exp=input("Experians :- ")
    temp+=[name,age,salary,exp,]
    final+=[temp,]
search=input("Enter the name:- ")
flag=True
for i in final:
    if search in i:
        print(i)
        flag=False
if(flag):
    print("not found!")
