l=['a','b','c','d','e','f','g','h','i','j']
count=0
for i in l:
    if i in"aeiouAEIOU":
        count+=1
print("The total number of vowal is :- ",count)

l2=[i for i in range(21) if i%2==0]
print(l2)