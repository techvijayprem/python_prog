l1=[i for i in range(1,10)]
max=l1[0]
min=l1[0]
for i in l1:
    if(i >max):
        max=i
    if(i<min):
        min=i
print("Max is :- ",max,"min is :- ",min)

#p16-17
odd=[i for i in l1 if i%2!=0]
even=[i for i in l1 if i%2==0]
print("odd numbers :- ",odd)
print("even numbers :- ",even)