import os
#p1
'''
p=open("a.txt","w")
p.write("rahul ")
p.close()
p=open("a.txt","w+")
p.write("anshi ")
p.close()
p=open("a.txt","a")
p.write("khushali ")
p.close()
p=open("a.txt","a+")
p.write("krithna ")
p.close()
'''
#p2
'''
p=open("a.txt","r")

ans=p.read()
print(ans)#p2
print(len(ans))#p3
p.seek(0,0)
for i in p:
    print(i,"the length :- ",len(i))
p.seek(0,0)
ans=p.read().split()
print("the total wordls are :- ",len(ans))   
for i in ans:
    print(i[::-1])
p.close()

#p7
p=open("b.txt","w")
lis=["rahul ","is ","good ","boy "]
for i in lis:
    p.write(i)
p.close()

#p8
name=input("Enter the name of file :- ")#
if os.path.isfile(name):#p9
    p=open(name,"r+")
    for i in p:
        print(i)
    p.write(" hello")#p10
    p.seek(0,0)
    p.write("rahul is a")
    p.close()
    
else:
    print("File not exist")

#p12
p=open("a.txt","r")
r=open("b.txt","w")
r.write(p.read())
r.close()
p.close()

#p13
p=open("a.txt","r")
p.seek(10,0)

p.close()

#p14
name=input("Enter the name of file :- ")#
if os.path.isfile(name):#p9
    p=open(name,"r+")
    num=eval(input("Enter the number :-"))
    p.seek(num,0)
    word=input("Enter the sentence :-")
    p.write(word)
    
else:
    print("File not exist")
'''
#p15
f=open("a.txt","r")
abc=f.read()
f.seek(0,0)
for i in range(len(abc)):
    if i%2==0:
        f.seek(i)
        print(f.read(1))
f.close()

#p16
f=open("a.txt","r")
for i in f:
    if 
    print(i)
    
f.close()

        
 
        
       
    
