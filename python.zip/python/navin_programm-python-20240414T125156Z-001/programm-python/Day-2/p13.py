

num1=eval(input("Enter the number :- "))
ans=0
while(num1>0):
    rem=num1%10;
    ans=(ans*10)+rem
    num1=int(num1/10)


print("the reverse of nuber is ",ans)
