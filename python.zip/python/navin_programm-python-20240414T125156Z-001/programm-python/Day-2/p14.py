for i in range(1,50):
    print(i)
