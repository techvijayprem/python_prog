
num1=eval(input("Enter the number :- "))

if(num1%2==0):
    print("it is an even number ")
else :
    print("It is an odd number ")