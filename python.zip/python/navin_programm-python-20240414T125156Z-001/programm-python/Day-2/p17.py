
for j in range(2,50):
    flag=True
    for i in range(2,int(j/2)+1):
        if(j%i==0):
            flag=False;
    if(flag):
        print(j)
    

