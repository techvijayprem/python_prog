num=eval(input("Enter the number :- "))
print("Binary is ",bin(num),"hexadecimal is ",hex(num),"octal is ",oct(num))