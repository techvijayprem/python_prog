
num1=eval(input("Enter the number :- "))
num2=eval(input("Enter the number :- "))

print("Binary right shift",num1>>1)
print("Binary left shift ",num2<<1)