num1=eval(input("Enter the number :- "))

if(num1>0):
    print("num is positive ")
elif(num1<0):
    print("num is negative ")
else:
    print("num is zero ")