
num1=eval(input("Enter the number :- "))
num2=eval(input("Enter the number :- "))

print("Binary and ",num1&num2)
print("Binary Or ",num1|num2)