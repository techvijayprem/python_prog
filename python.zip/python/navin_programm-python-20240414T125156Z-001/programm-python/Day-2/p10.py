
num1=eval(input("Enter the number :- "))
flag=True
for i in range(2,int(num1/2)+1):
    if(num1%i==0):
        flag=False;
if(flag):
    print("It is an prime number")
else:
    print("It is an non prime number")