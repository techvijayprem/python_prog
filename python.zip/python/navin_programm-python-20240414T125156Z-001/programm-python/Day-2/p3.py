# if program 
n1=eval(input("Enter num1 :-"))
n2=eval(input("Enter num2 :-"))

if(n1>n2):
    print(True)
else:
    print(False)
