# if program 
n1=eval(input("Enter num1 :-"))
n2=eval(input("Enter num2 :-"))
n3=eval(input("Enter num3 :-"))
if(n1>n2 and n1>n3):
    print("num1 is greater then num2 and num3")
    if(n2>n3):
        print("num 3 is lesser then all")
    else:
        print("num 2 is lesser then all")
        
elif(n2>n1 and n2>n3):
    print("num2 is greater then num1 and num4")
    if(n1>n3):
        print("num 3 is lesser then all")
    else:
        print("num 1 is lesser then all")
else: 
    print("num3 is greater then num2 and num1")
    if(n2>n1):
        print("num 1 is lesser then all")
    else:
        print("num 2 is lesser then all")