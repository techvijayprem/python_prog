#1.	Define a function 'sort_matrix' that takes a matrix 'M' (list of lists) as input

M = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
f=list(sorted(M,key=lambda x:sum(x)))
print(f)

#2.	Define a function 'extract_string' that takes a list of strings 'str_list1' and an integer 'l' as input

str_list1 = ['Python', 'list', 'exercises', 'practice', 'solution']
num=8
f=list(filter(lambda x: len(x)==num,str_list1))
print(f)

#3.	Create a list of tuples named 'subject_marks', each tuple containing a subject and its corresponding marks

subject_marks = [('English', 88), ('Science', 90), ('Maths', 97), ('Social sciences', 82)]
f=list(sorted(subject_marks,key=lambda x:x[1]))
print(f)


#4.	Create a list of dictionaries named 'models', each dictionary representing a mobile phone model with 'make', 'model', and 'color' keys
models = [
    {'make': 'Nokia', 'model': 21, 'color': 'Black'},
    {'make': 'Mi Max', 'model': 20, 'color': 'Gold'},
    {'make': 'Samsung', 'model': 17, 'color': 'Blue'}]
models.sort(key=lambda x:x['model'])
print(models)

#5.	Create a list of mixed inputs by taking user input and write a lambda function to check the element in the list is a digit or not.

ans=[]
l = ['1','2','a','b','3','c','d']
for i in l:
    if i.isdigit():
        ans.append(True)
    else:
        ans.append(False)
print(ans)