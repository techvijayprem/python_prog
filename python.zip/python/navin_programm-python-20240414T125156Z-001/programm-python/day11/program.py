#p1
M = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
def sort_matrix(M):
    
    M.sort(key=lambda x:sum(x))
    print(M)
sort_matrix(M)
#p2
l1=["rahul","parth","gaurang","darshil"]
k=int(input("Enter the numbr :- "))
def extract_string(l1,k):
    ans=[]
    for i in l1:
        if len(i)==k:
            ans.append(i)
    return ans
print(extract_string(l1, k))
#p3
subject_marks = [('English', 88), ('Science', 90), ('Maths', 97), ('Social sciences', 82)]
subject_marks.sort(key=lambda x:x[1])
print(subject_marks)
#p4
models = [
    {'make': 'Nokia', 'model': 21, 'color': 'Black'},
    {'make': 'Mi Max', 'model': 20, 'color': 'Gold'},
    {'make': 'Samsung', 'model': 17, 'color': 'Blue'}]
models.sort(key=lambda x:x['model'])
print(models)
#p5
ans=[]
l = ['1','2','a','b','3','c','d']
for i in l:
    if i.isdigit():
        ans.append(True)
    else:
        ans.append(False)
print(ans)