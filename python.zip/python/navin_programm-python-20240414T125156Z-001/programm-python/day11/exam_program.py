index=0
detail={}
def specificResult():
    name=input("Ente the name for result :- ")
    for i in detail.values():                         
        if i['name'] == name:
            for j in i['marks']:                                   
                count=1
                total=sum(j)
                per=total/3
                print("The result of",i['name'],"of ",count,"attempt is  total is ",total,"the per is :- ",per)
                count+=1
def result():
    for i in detail.values():
            for j in i['marks']:
                count=1
                total=sum(j)
                per=total/3
                print("The result of",i['name'],"of ",count,"attempt is  total is ",total,"the per is :- ",per)
                count+=1
def addstud():
    stud={}
    name=input("Enter the name :- ")
    age=eval(input("Enter the age :- "))
    lis=[]
    for j in range(2):
        sub1=eval(input("Enter the subject 1 mark"))
        sub2=eval(input("Enter the subject 2 mark"))
        sub3=eval(input("Enter the subject 3 mark"))
        tup=(sub1,sub2,sub3)
        lis+=(tup,)
    stud['name']=name
    stud['age']=age
    stud['marks']=lis
    detail[index]=stud
    globals()['index']+=1
    
def menue():
    while 1:
       print('''
          1.add student
          2.result
          3.overall result
          4.exit
          ''')
       ch=input("Select the choice :- ")
       if(ch in "aA"):
            addstud()
            
       elif(ch in "bB"):
           specificResult()
       elif(ch in "cC"):
          result()
          
       elif(ch in "dD"):
           break
       else:
           print("You enter the worng choice  ")
         

for i in range(1,4):
    stud={}
    name=input("Enter the name :- ")
    age=eval(input("Enter the age :- "))
    lis=[]
    for j in range(2):
        sub1=eval(input("Enter the subject 1 mark"))
        sub2=eval(input("Enter the subject 2 mark"))
        sub3=eval(input("Enter the subject 3 mark"))
        tup=(sub1,sub2,sub3)
        lis+=(tup,)
    stud['name']=name
    stud['age']=age
    stud['marks']=lis
    detail[i]=stud
    index=i+1
print(detail)
menue()
    

