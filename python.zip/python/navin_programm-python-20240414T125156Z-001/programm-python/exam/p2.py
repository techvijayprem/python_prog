tour={'ohm':['drowing','swimming'],
      'jeed':['skipping','chess'],
      'mit':['quiz','swimming'],
      'smita':['swimming','chess']}
part={}
while(True):
          print('''
          A.total count
          B.maximum participants 
          C.just one participant''')
          
          ch=input("Enter the value :- ")
          if(ch=='a'):
              total=0
              for i in tour:
                  for j in tour[i]:
                      if(j in part.keys()):
                          part[j]+=1
                      else:
                          part[j]=1
                              
              print(part)
          elif(ch=='b'):
                    maxnum=0;
                    maxind=''
                    for i in part:
                        if(part[i]>maxnum):
                            maxnum=part[i]
                            maxind=i
                    print("The tournament ",maxind,"got highest number of studendent which is",maxnum)
          elif(ch=='c'):
                                print("This are the tournament :- ")
                                for i in part:
                                    if(part[i]==1):
                                        print(i)
          else:
                                            break;

        
    