l1=[[1,2,3],[2,3,4],[5,6,7]]
l2=[[9,8,7],[6,5,4],[4,3,2]]
l3=[]
for i in range(len(l1)):
    temp=[]
    for j in range(len(l1[i])):
        temp.append(l1[i][j]+l2[i][j])
    l3.append(temp)
print(l3)
        