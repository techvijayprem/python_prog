str1=input("enter the string:-")
l1=str1.split()
print("The total words are ",len(l1))
