import pickle

dic=[]

def addData():
    detail={}
    rollno=int(input("Enter the rollno :- "))
    name=input("Enter the name :- ")
    age=int(input("Enter the age :- "))
    hobby=input("Enter the hobby  :-")
    marks=int(input("Enter the marks:- "))
    detail['rollno']=rollno
    detail['name']=name
    detail['age']=age
    detail['hobby']=hobby
    detail['marks']=marks
    dic.append(detail)
    with open('abcd.bin','wb') as f:
        pickle.dump(dic, f)
    with open('abcd.bin','rb') as f1:  
        obj=pickle.load(f1)
        print(obj)
    
def update():
    roll=int(input("Enter the roll no:- "))
    name=input("Enter the name to rename :- ")
    with open('abcd.bin','rb') as f:  
        obj=pickle.load(f)
        for i in obj:
            if i['rollno']==roll:
                i['name']=name
    with open('abcd.bin','wb') as f:
         pickle.dump(obj, f)           
    with open('abcd.bin','rb') as f1:  
        obj=pickle.load(f1)
        print(obj)
def delete():
    roll=int(input("Enter the roll no:- "))
    with open('abcd.bin','rb') as f:  
        obj=pickle.load(f)
        for i in obj:
            if i['rollno']==roll:
               obj.remove(i)
    with open('abcd.bin','wb') as f:
        pickle.dump(obj,f)
    with open('abcd.bin','rb') as f1:  
        obj=pickle.load(f1)
        print(obj)
while 1:
    print('''
          1.add
          2.update
          3.delte
          enter any number for exit
          ''')
    ch=int(input("enter the chouice :- "))
    if ch==1:
        addData()
    elif ch==2:
        update()
    elif ch==3:
        delete()
    else:
        break
    