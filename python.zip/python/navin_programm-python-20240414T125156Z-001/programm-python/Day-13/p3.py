with open('a.txt','w') as f:
    while True:
        a=input("Ente4r the  stringt :- ")
        if a=='@':
            break
        else:
            f.write(a+"\n")


