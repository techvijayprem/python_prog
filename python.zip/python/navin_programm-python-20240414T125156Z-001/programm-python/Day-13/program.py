a=''' '''
with open('b.txt','r') as r:
    a=r.read()
    
    

print(a)
l=[]
count=0
with open("a.txt",'w') as f:
    for i in a.split("\n"):
        count+=1
        l.append((count,len(i.split())))
        f.write(str(l))
        
    
print(l)