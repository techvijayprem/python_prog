a=''' '''
with open('b.txt','r') as r:
    a=r.read()

with open('num.txt','w') as w:
    for i in a:
        if i.isdigit():
            w.write(i)
with open('char.txt','w') as w:
    for i in a:
        if i.isdigit()==False:
            w.write(i)