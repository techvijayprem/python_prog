import os


def rename():
    name=input("Enter the file to rename :- ")
    rename=input("The rename value :- ")
    os.rename(name,rename)
def createFile(a='abc.txt'):
    o=open(a,'w')
    o.close()
def read():
    name=input("Enter the file name :- ")
    with open(name,'r') as w:   
            print(w.read())
def delete():
    name=input("Enter the file name :- ")
    os.remove(name)
def mkdir():
    os.mkdir('abc')
def liset():
    name=input("enter the directery name :- `")
    os.listdir(name)
def lisetoftxt():
    for i in os.listdir():
         if i.endswith('.txt'):
             print(i)
def startwith():
    for i in os.listdir():
         if i.startswith('b'):
             print(i)
    
while 1:
      print('''
      1.create
      2.read
      3.delete
      4.mkdir
      5.list of file
      6.rename
      7.all txt file
      8.start with b
      enter any number to exit
      ''')
      ch=int(input("Select the choice :- "))
      if ch==1:
          createFile()
      elif ch==2:
              read()
      elif ch==3:
          delete()
      elif ch==4:
          mkdir()
      elif ch==5:
          liset()
      elif ch==6:
          rename()
      elif ch==7:
          lisetoftxt()
      elif ch==8:
          startwith()
      else :
          break

