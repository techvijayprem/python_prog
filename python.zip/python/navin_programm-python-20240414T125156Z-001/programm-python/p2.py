l=['Chiku','Mango','Apple']
def add(name):
        l.append(name)
        print(l)

def insert(pos,name):
    l.insert(pos,name)
    print(l)
    
def update(name):
    if 'Chiku' in l:
        i=name
    print(l)
def remove(name):
    l.remove(name)
    print(l)
def sort():
    l.sort()
    print(l)
print(l)
print('''
        1.Add Fruit
        2.Insert Fruit at particular position
        3.Update Fruit
        4.Remove Fruit
        5.Arrange Fruit
        ''')
ch=int(input("Enter your choice"))
if(ch==1):
    name=input("Enter name to insert:")
    add(name)
elif(ch == 2):
    insert(pos=2,name='Kiwi')
elif(ch == 3):
    name=input("Enter name to change")
    update(name)
elif(ch==4):
    remove('Chiku')
elif(ch==5):
    sort()
else:
    print("Invalid")
    
    
    
    
        
