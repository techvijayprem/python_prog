#p1
f=lambda a,b:a if a>b else b
print(f(1,2))
#p2
g=lambda a,b,c:a if(a>b and a>c) else b if (b>a and b>c) else c
print(g(1,2,3))
#p3
num=eval(input("Enter the number :- "))
o=lambda num: num*5 if(num%2==0) else num*10
print(o(num))
#p4
l=[1,2,3,4,'a','b','c']
strlist=lambda l:[i for i in l if (type(i)==str)]
print(strlist(l))
intlist=lambda l:[i for i in l if (type(i)==int)]
print(intlist(l))
#p5
print("using filter :- ",list(filter(lambda x:type(x)==str,l)))
print("using filter :- ",list(filter(lambda x:type(x)==int,l)))
#p6
string=['aba','bab','rahul','ravi']
print("all palindrom string :- ",list(filter(lambda x:x==x[::-1],string)))
#p7
string=input("Enter the string :- ")
print("all vowles string :- ",list(filter(lambda x:x in "aeiouAEIOU",string)))
#p8
l=[1,2,3,4,5,6,7,8]
even=list(filter(lambda x:x%2==0,l))
odd=list(filter(lambda x:x%2!=0,l))
print("The odd is :- ",odd,"Even is :- ",even)
#p9
pc=lambda x,y: x*y if(type(x)==int and type(y)==int) else str(x)+str(y)
print(pc('a',3))
#p10
l=[(120,'Apple'), (20,'Banana'),(50,'Chikoo'),(100,'Pinaple')]
l.sort(key=lambda x:x[0])
print(l)
#p11
student=['rahul','ravi','gaurnag','darshil','']
print(list(filter(lambda x:len(x)<6,student)))
#p12
student=list(filter(lambda x:len(x)!=0,student))
print(student)
#p13
l=[1,2,3,4,-2,-1,1,3]
l=list(filter(lambda x:x>=0,l))
print(l)
#p14
l=list(filter(lambda x:l.count(x)==1,l))
print(l)
#p15
d=[{'name': 'dax', 'age': 25}, {'name': 'Bina', 'age': 22}, {'name': 'amit', 'age': 25}]
print(list(sorted(d,key=lambda x: (x['age'],x['name']))))


