import matplotlib.pyplot as p
#p2-3
'''
p.plot([1,7],[1,7])
p.plot([7,14],[7,1])
p.plot([4,10.5],[4,4])'''
#p4
'''p.plot([1,7],[1,1])
p.plot([1,1],[7,1])
p.plot([1,7],[7,7])
p.plot([1,7],[4,4])


p.plot([1,1],[7,1])
p.plot([1,7],[4,7])
p.plot([1,7],[4,1])'''
#p7
p.xlabel("xlabel")
p.ylabel("ylabel")
#p6
'''
p.plot([1,4],[4,7])
p.plot([7,4],[4,7])
p.plot([1,4],[4,1])
p.plot([4,7],[1,4])'''
#8
p.plot([1,4],[4,7],"g:")