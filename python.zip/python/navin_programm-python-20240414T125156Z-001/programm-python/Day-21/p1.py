import pandas as pd
#p1
d={"d1":1,"d2":2,"d3":3}
S=pd.Series(d)
print(S)
df=pd.DataFrame(S)
print(df)
#p2
Students=["rahul","aanshi","nikhil"]
Score=[55,66,77]
Age=[21,35,22]
df=pd.MultiIndex.from_arrays([Students,Score,Age], names=["stu","score","age"])
print(df)
#p3
#a
d={"empid":[1,2,3],"name":["rahul","aanshi","nikhil"],"sal":[1200,1300,1400]}
df=pd.DataFrame(d)
mul=pd.MultiIndex.from_frame(df)
print(mul)
#b
df=pd.read_excel("student.xlsx")
mul=pd.MultiIndex.from_frame(df)
print(mul)
#p4
l=[(1,"rahul",55,6,77,"fale"),(2,"ravi",66,88,66,"pass"),(3,"raj",77,77,77,"pass"),(4,"rohan",55,88,88,"pass"),(5,"aanshi",66,33,11,"fale")]
df=pd.DataFrame(l,index=('s1','s2','s3','s4','s5'),columns=("rollno","name","sub1","sub2","sub3","pass/fale"))
print(df)
#p5
g=df.groupby("pass/fale")
print(g.count())
#p6
print("min mark in sub 1 :- ",df["sub1"].min(),"max mark in sub 1 :- ",df['sub1'].max())
print("min mark in sub 2 :- ",df["sub2"].min(),"max mark in sub 2 :- ",df['sub3'].max())
print("min mark in sub 3 :- ",df["sub3"].min(),"max mark in sub 3 :- ",df['sub3'].max())