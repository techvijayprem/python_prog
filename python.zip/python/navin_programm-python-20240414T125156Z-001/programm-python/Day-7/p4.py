#p4
def single(list1):
    list2=[]
    for i in list1:
        
        if i not in list2:
            print(i)
            list2+=[i,]
    return list2
list1=[1,1,2,2,3,3,4,4]
list1=single(list1)
print(list1)
#p5
def multi(l):
    mul=1
    for i in l:
        mul*=i
    return mul
print(multi(list1))
#p6
def checkit(num):
    if num in range(1,10):
        print("it is in the range")
num=int(input("Enter the number :- "))


