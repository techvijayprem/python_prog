def addOrmul(val1,val2):
    if(type(val1)==int and type(val2)==int):
        print("The multi piliction is :- ",val1*val2)
    if(type(val1)==str or type(val2)==str):
         print("The string is :- ",val1+val2)
         

addOrmul(1,2)        
         
    