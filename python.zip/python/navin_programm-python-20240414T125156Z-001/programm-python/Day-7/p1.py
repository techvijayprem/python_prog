def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def mul(a,b):
    return a*b
def div(a,b):
    return a/b
while(True):
    print('''
          A.add
          b.sub
          c.mul
          d.div
          e.exit
          ''')
    ch=input("Enter the choice :- ")
    num1=eval(input("Enter the number 1 :- "))
    num2=eval(input("Enter the number 2 :- "))
    if(ch=='a'):
        print("The sum is :- ",add(num1,num2))
    elif(ch=='b'):
        print("The subtrection is :- ",sub(num1,num2))
    elif(ch=='c'):
        print("The multiplicatin is :- ",mul(num1,num2))
    elif(ch=='d'):
        print("The divison is :- ",div(num1,num2)) 
    else:
        break
        

