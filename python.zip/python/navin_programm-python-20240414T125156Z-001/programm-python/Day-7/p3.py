def binary(num1):
    return bin(num1)
def hexaa(num):
    return hex(num)
num1=eval(input("Enter the decimal value :-"))
print("The binany will be - ",binary(num1))