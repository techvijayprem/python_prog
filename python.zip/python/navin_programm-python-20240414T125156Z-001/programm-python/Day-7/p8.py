def prim(num):
    for i in range(2,int(num/2)+1):
        if num%i==0:
            return False
    return True
def primes():
    for i in range(2,10):
        if(prim(i)):
            print(i)
primes()