def upper(str1):
    coutn=0
    for i in str1:
        
        if i>='A' and i<='Z':
            coutn+=1
    return coutn
def lowwer(str1):
    coutn=0
    for i in str1:
        
        if i>='a' and i<='z':
            coutn+=1
    return coutn
str1=input()
print("the upper are :- ",upper(str1),"the lower are :- ",lowwer(str1))