def fact(num1):
    ans=1
    for i in  range(1,num1+1):
        ans*=i
    return ans
num=int(input("Enter the number :- "))
print("The factorial is :-  ",fact(num))