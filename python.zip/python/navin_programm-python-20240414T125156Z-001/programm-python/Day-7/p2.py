def rad(r):
    return 3.14*r*r
def tri(l,b):
    return 0.5*l*b
def rec(l,b):
    return l*b
r=eval(input("Enter the radious :- "))
print("The radious is :- ",rad(r))
h=eval(input("Enter the height :- "))
b=eval(input("Enter the base :- "))
print("The area of triangle is :- ",tri(h,b))
l=eval(input("Enter the lenght :- "))
b=eval(input("Enter the breathe :- "))
print("The are of rectangel is :- ",rec(l,b))

