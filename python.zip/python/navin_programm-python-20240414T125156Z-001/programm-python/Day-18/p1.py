#import mysql.connector as db
import sqlite3 as db
from tkinter import *
def insert():
    data=e1.get()
    print(data)
window = Tk()
window.title("Input from User")
window.geometry('350x350')
l1=Label(window,text="enter the value :").place(x=10,y=20)
e1=Entry(window,width=20)
e1.place(x=110,y=20)

b1=Button(window,text="insert",command=insert).place(x=12,y=60)
b2=Button(window,text="update",command=insert).place(x=80,y=60)
b3=Button(window,text="delete",command=insert).place(x=152,y=60)
b3=Button(window,text="delete",command=insert).place(x=152,y=60)


window.mainloop()

