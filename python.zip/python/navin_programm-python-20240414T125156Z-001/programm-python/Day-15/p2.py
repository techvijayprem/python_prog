import pickle
class Myexcept(Exception):
    pass
l={}
result={}
try:
    for i in range(2):
        num=int(input("enter the roll no :- "))
        marks=()
        numofsub=int(input("Enter the number of subject :- "))
        if numofsub != 5:
            raise Myexcept("The number of subject should be 5")
        for j in range(numofsub):
            mark=int(input("Enter the mark :- "))
            assert(mark<=50),"Marks should not greater then 50"
            marks+=(mark,)
            
        l[num]=marks
        total=sum(l[num])
        per=total/5
        result[num]=[total,per]
    f=open('result.bin','wb')
    pickle.dump(result,f)
    f.close()
    with open('result.bin','rb') as f:
        num=int(input("Enter the roll no for result :- "))
        obj=pickle.load(f)
        for i in obj:
            if num==i:
                print("The roll no ",i," has total ",obj[i][0],"and the per is ",obj[i][1])
    
        
except AssertionError as a:
    print(a)
except Myexcept  as e:
    print(e)
except IOError:
    print("Sothing problem in binary file !")
else:
    print("Program ended!")