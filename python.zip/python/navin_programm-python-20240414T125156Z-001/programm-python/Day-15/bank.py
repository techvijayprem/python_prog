import pickle as p
try:
    account={}
    def createAccount():
        name=input("Enter the customer name :-")
        cust_id=eval(input("Enter the customer id:- "))
        account[cust_id]={'name':name,'balance':5000}
        print("your customer id is ",cust_id,"your name is ",name,"please depossit 5000")
        with open('acc.bin','wb') as c:
            p.dump(account,c)
    def printStatment():
        cust_id=int(input("Etner the customer id :- "))
        with open('acc.bin','wr') as c:
            obj=p.load(c)
            for i in obj:
                if i==cust_id:
                      print("your balance is ",obj[i])
               
    while 1:
        print('''
              1.create account
              2.print balance
              3.witdraw
              4.deposit
              Enter the any number for exit
              ''')
        ch=int(input("Select choice:-"))
        if ch==1:
            createAccount()
        elif ch==2:
            printStatment()
        elif ch==3:
            withdrowStatment()
        elif ch==4:
            deposit()
        else:
            break
