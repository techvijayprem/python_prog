l={}
try:
    for i in range(2):
        num=int(input("enter the roll no :- "))
        marks=[]
        for j in range(3):
            mark=int(input("Enter the mark :- "))
            marks+=[mark,]
        print(marks)