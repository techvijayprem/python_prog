age=eval(input("Enter the age :-"))
salary=25000
l=[1]
try:
    assert (type(age)== int),'Age not a number!'
    assert(age>=18 and age<=25),'age not between the range'
    assert(salary>10000),'salary should be greater then 10000'
    l.append(age)
    l.append(salary)
    hra=salary*0.1
    l.append(hra)
    f=open('info.txt','r')
    f.write(str(l))
    
except AssertionError as a:
    print(a)
except IndexError as i:
    print(i)
except NameError:
    print("The salary is not define")
except IOError:
    print("You open the file in read mood so you can not perform write operation")
else:
    print("Program is ended")