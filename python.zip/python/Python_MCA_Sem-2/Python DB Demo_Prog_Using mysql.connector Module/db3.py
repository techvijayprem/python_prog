import MySQLdb as db

try:
    
    conn = db.connect(host='localhost', database='db', user='root', password='root')

    cursor = conn.cursor()

    query = "insert into empData values('%d', '%s', '%c', '%s')"

    eno = 2
    ename= 'Aarya'
    gender='M'
    doj = '2013-01-31'
    args = (eno,ename,gender, doj)
    cursor.execute(query %args)

    print("Record inserted successfully...")

except db.Error as ex:
    print(ex)

cursor.close()
conn.close()
