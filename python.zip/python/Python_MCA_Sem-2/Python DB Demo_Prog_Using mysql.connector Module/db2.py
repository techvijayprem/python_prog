import MySQLdb as db

try:
    
    conn = db.connect(host='localhost', database='db', user='root', password='root')

    cursor = conn.cursor()

    #query = "drop table if exists empData"
    #cursor.execute(query)

    #query = "create table empData(eno INT, ename VARCHAR(20), gender CHAR(1))"
    #query = "alter table empData add column (doj date)"

    query = "Insert into empData values(1, 'Urja', 'F', '2010-02-23 00:00:00')"
    cursor.execute(query)

    print("Table created successfully...")

except db.Error as ex:
    print(ex)

cursor.close()
conn.close()
