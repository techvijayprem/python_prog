
import MySQLdb as mysqldb

conn = mysqldb.connect(host='localhost', database='db', user='root', password='root')

cursor = conn.cursor()
cursor.execute('select * from contacts')

#Method 1: fetchone just to fetch 1 record
'''
row = cursor.fetchone()

while row is not None:
    print(row)
    row = cursor.fetchone()
''' 
#OR Method 2: use the fetchall() to fetch all records at a time

rows = cursor.fetchall()
'''
for row in rows:
    print(row)
'''
# To fetch a specific column:

for row in rows:
    print("Name is ", row[1])
    print("Phone No is ",row[0])
cursor.close()
conn.close()

