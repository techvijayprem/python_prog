import mysql.connector as db

conn = db.Connect(host='localhost', database='Testing', user='root', password='')
print(conn)
cursor = conn.cursor()

cursor.execute("select * from users")

#row = cursor.fetchone()
#print(row)

#cursor.close()
conn.close()

