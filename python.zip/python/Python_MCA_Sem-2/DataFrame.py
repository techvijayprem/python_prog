import pandas as pd

'''
d = [1,2,3,4,5]

df = pd.Series(d)
print(df)

calories = {"day1": 420, "day2": 380, "day3": 390}

df = pd.Series(calories, index = ["day1", "day2","day3"])
print(df)

students = ['Garg','Harsh','Sona','Ritu']
marks = [94,87,90,75]
age = [22,21,23,20]

df = pd.MultiIndex.from_arrays([students,marks,age], names=('Name', 'Marks','Age'))

for i in df:
    print(i)

d = {"empid":[1001,1002,1003,1004,1005],
    "ename":['urja','dahrm','aarya','hetansh','purna'],
   "sal":[1000,2000,3000,4000,5000]}

df1 = pd.DataFrame(d)
print(df1)
df1 = pd.MultiIndex.from_frame(df1)

for i in df1:
    print(i)
'''   
l = [(1,'urja',200),(2,'dharm',200),(3,'aarya',150),(4,'het',150),(5,'purna',200)]
df = pd.DataFrame(l,index=['S1','S2','S3','S4','S5'],columns=('RollNo','Name','Score'))
print(df)

g1 = df.groupby("Score")
print(g1.mean())

df = pd.DataFrame( 
    [ 
        ("Corona Positive", 65, 99), 
        ("Corona Negative", 52, 98.7), 
        ("Corona Positive", 43, 100.1), 
        ("Corona Positive", 26, 99), 
        ("Corona Negative", 30, 98.7), 
    ], 
      
    index=["Patient 1", "Patient 2", "Patient 3", 
           "Patient 4", "Patient 5"], 
      
    columns=("Status", "Age(in Years)", "Temperature"), 
) 

print(df) 
g2=df.groupby("Status")
g3 = df.groupby(['Status','Temperature'])
g4 = df.groupby('Temperature')

print(g3.min())
print(g2.max())
print(g3.count())  
    
    
    