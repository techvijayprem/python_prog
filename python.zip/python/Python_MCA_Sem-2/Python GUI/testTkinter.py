from tkinter import *

w = Tk()

w.geometry("350x350")

def clicked():
    n = i.get()
    l2.configure(text=n)

l = Label(w, text="Name").place(x=10,y=50)

i = Entry(w,width=20)
i.place(x=10,y=100)

b = Button(w,text="OK", command=clicked).place(x=10,y=150)
l2= Label(w, text="")
l2.place(x=10,y=200)
w.mainloop()
