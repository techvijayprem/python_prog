#import mysql.connector as db
import sqlite3 as db
from tkinter import *

window = Tk()
window.title("Input from User")
window.geometry('350x350')

def clicked():
    uid = int(e1.get())
    email= e2.get()
    
    #conn = db.connect(host='localhost',database='db',user='root', password='')
    conn = db.connect("MyDB")

    cur = conn.cursor()
    cur.execute('''create table if not exists emp([eno] number, [ename] varchar(20))''')
    cur.execute('''insert into emp values(2, "urja")''')

    conn.commit()

    query = "update emp set ename = '%s' where eno = %d"

    args = (email,uid)

    cur.execute(query %args)

    cur.execute("select * from emp")
    r = cur.fetchall()
    print(r)
    cur.close()
    conn.close()
    
    l3.configure(text="Record Updated... ")    

l1 = Label(window, text='User Id: ',font=('Arial',12))
l1.place(x=10,y=70)

e1 = Entry(window, width=20)
e1.place(x=100,y=70)

l2 = Label(window, text='Name: ',font=('Arial',12))
l2.place(x=10,y=100)

e2 = Entry(window, width=20)
e2.place(x=100,y=100)

btn = Button(window, text="Update", command=clicked)
btn.place(x=20, y=150)

l3 = Label(window, text='Employee will be updated..: ',font=('Arial',12))
l3.place(x=10,y=200)

window.mainloop()
