import logging

age=input("Enter age")

class NotInRange(Exception):
    pass

try:
    assert age.isdigit(), "Age must be a number"

    if(int(age) < 18 or int(age) > 25):
        raise NotInRange("Age must be between 18-25 only")
    #l=[age]
    #f=open("f1.txt")
    #f.write("l") #value error
    #f.close()
    print(l.split(1,2)) #Attribute Error
    
except AssertionError as a:
    print(a)
except TypeError:
    print("Type Missmatch error")
except NameError:
    print("Variable not found")
except IndexError:
    print("Index out of bound")
except ValueError as v:
    print("Value Error", v)
except AttributeError:
    print("AttributeError")
except IOError as io:
    print(io)
except NotInRange as m:
    print(m)
    logging.basicConfig(filename="test.log", level=logging.ERROR)
    logging.error(m)
finally:
    print("Prog Ended")
