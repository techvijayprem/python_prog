import pandas as pd
import matplotlib.pyplot as plt


# Read from excel file
df = pd.read_excel("empdata.xlsx","Sheet1")
'''
# Read from .csv file
df = pd.read_csv("empdata.csv")

# Dataframe from Python Dictionary Object
dataDic = {"EmpId":[1001,1002,1003,1004,1005],
           "EmpName":["Ankit","Khusbu","Purna","Hiral","Prayag"],
           "Salary":[100000,12000,15000,25000,54000]}

df = pd.DataFrame(dataDic)

# Dataframe from Python List with tuple Object
empList = [(1,"Ashish",5000,"10-13-2006"),
           (2,"Sparh",1000,"12-12-2005"),
           (3,"Nitya",6500,"01-01-2004"),
           (4,"Dhyana",96500,"05-06-2004"),
           (5,"Hetvi",36500,"08-07-2004"),
           (6,"Harsh",16500,"01-01-2004")]

df = pd.DataFrame(empList,columns=["EmpID", "EmpName", "Salary", "JoinDate"])

'''

print(df)

'''

t = df.shape
print(t[0])
r,c = df.shape
print(c)

print(df.head(1))
print(df.tail(2))
df2 = df.tail(2)

print(df[1::3])
print(df.columns)
print(df.EmpName)
df[['EmpID','EmpName']]

'''
x = df['empid']
y = df['sal']
plt.bar(x,y, label='Employee Data',color='red')

plt.xlabel('Employees')
plt.ylabel('Salary')
plt.title('Employe wise salary')
plt.legend()
plt.show()