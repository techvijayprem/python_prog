import pandas as pd
import re
# this function formats output
def printS(title, msg):
    print("\r\n------------------------------------------------------------\r\n")
    print(title, ":\r\n")
    print(msg, "\r\n")


# this will "clear" screen
print("\n"*37)

# create data frame from excel file and display.
df = pd.read_excel("empdata.xlsx", parse_dates=['doj'])
#printS('Data Frame', df)

'''
# get number of rows and columns
printS("Number of Rows & Columns", df.shape)


#get rows and columns separately
r, c = df.shape
printS("get number of rows and columns separately", "#rows: {0}; #columns: {1}".format(r, c))


#get top and last rows from data frame
df1 = df.head()
printS("Top rows", df1)
printS("Last rows", df.tail())

printS("Top 2 rows", df.head(2))
printS("Last 2 rows", df.tail(2))


#get range of rows. this is list getting elements between indexes from a list
printS("Rows from index 2 to 5", df[2:5])
printS("Alternate rows", df[::2])
printS("Rows in reverse order", df[5::-1])


#get column names
printS("Get column names", df.columns)


#get data from a specific column
printS("Data from column empid", df.empid)


#get data from multiple column
printS("Data from columns empid & ename", df[['empid', 'ename']])


#get min and max values
printS("Min salary", df['sal'].min())
printS("Max salary", df['sal'].max())


#get statistics
printS("Stats of emp data", df.describe())


#querying/fildering data
printS("get rows with sal > 10000", df[df.sal >10000])
df2 = df[df.sal >10000]
df2 = df2['ename'][df2.age >= 30]
print(df2)

#Getting range index
printS("Range Index", df.index)

# setting a column as index
df1 = df.set_index('empid')
printS("Data frame with empid as index", df1)
printS("Row for empid 1004", df1.loc[1004])


# setting index on same data frame
df.set_index('ename', inplace = True)
printS("Data frame with ename as index", df)
printS("Row for 'Anant Nag'", df.loc['Anant Nag'])

# reset index (remove index on column)
df.reset_index(inplace = True)
printS("After resetting index", df)
'''
#sort on DOJ
df1 = df.sort_values('doj',ascending=False)
printS("Sorted on date of joning", df1)
df1 = df.sort_values(by=['doj','sal'],ascending=[False,True])
printS("Sorted on date of joning", df1)


df1 = df.ename
s = ' '
s = s.join(df1)
print(df1)
s = "Ashish, Bhumi, Anil, Sneha, Bhavya, Aanya, Zarna, Pooja, Amit"
i=0
#while (re.search(r'A\w*',s)!=None):
#print(re.findall(r'\bA\w*',s))
#print(re.findall(r'\bA[a-z]*',s))
print(re.findall(r'^A[...]',s))
i +=1

'''
#
# Handling missing data
#

df = pd.read_excel("empdata1.xlsx")
printS("data frame", df)

df1 = df.fillna(0)
printS("data frame with empty values replaced", df1)

df1 = df.fillna({ "ename" : "- Name Missing- ", "sal" : "0.0", "doj" : "00-00-0000" })
printS("data frame with empty values replaced", df1)

df1 = df.dropna()
printS("Rows with empty values removed", df1)
'''