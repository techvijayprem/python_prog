#import pylab
import matplotlib.pyplot as py

py.figure(1)
py.plot([1,2,3,4],[11,17,13,15],"go-",label="plt x y")

py.legend(loc='best')
py.xlabel('Roll No')
py.ylabel('Marks')
py.title('rcParameter Settings')

py.rcParams['lines.linewidth']=5
py.rcParams['axes.titlesize']=25
py.rcParams['axes.labelsize']=20
py.rcParams['xtick.labelsize'] = 16
py.rcParams['ytick.labelsize'] = 16
py.rcParams['xtick.major.size'] = 7
py.rcParams['ytick.major.size'] = 7
py.rcParams['lines.markersize'] = 10
py.rcParams['legend.numpoints'] = 3

py.figure(1)
py.plot([5,6,10,3],'g--', linewidth=5, markersize=20)

py.plot([1,2,3,4],[1,7,3,5], 'go:', [5,6,10,3], 'r+-.')
py.plot([1,2,3,4],[1,7,3,5], 'yo', [5,6,10,3], 'g^--', linewidth=3, markersize=10)

py.figure('A')
py.plot([0,1,2,3,4],[0,1,2,1,0],[1,3],[1,1])

py.show()
