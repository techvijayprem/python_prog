# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 17:31:43 2024

@author: urja
"""
import pandas as pd
import matplotlib.pyplot as plt

fp = open("temp.txt","r+")
vowels = ('a','A','e','E','i','I','o','O','u','U')
line = 0
d = {}
for i in fp:
    line += 1
    words = i.split()
    w = len(words)
    l = len(i) 
    #print("No. of words in line" , line , " are " ,w)
    #print("No. of letters in line" , line , " are " ,l)
    v = 0
    for letter in i:
        if letter in vowels:
            v += 1
    #print("No. of vowels in line" , line , " are " ,v)
    d[line] = [w,l,v]
#print("No of lines:", line)
print(d)
words=[]
letters = []
vowels = []
for values in d:
    vowels.append(d[values][2])
    letters.append(d[values][1])
    words.append(d[values][0])

df = pd.DataFrame(d)
df = df.transpose()
print(df)
df.columns=['Words', 'Letters', 'Vowels']
print(df)
#df.to_excel("test3.xlsx",'Analysis')

plt.plot(vowels, color="green",  linestyle='-', marker='v')
plt.plot(words,color="indigo",  linestyle='-.', marker='o')
plt.plot(letters,color="red",  linestyle='--',marker = '*')
plt.legend("VWL")
plt.show()
plt.bar(words,letters)
plt.xlabel('Words')
plt.ylabel('Letters')
plt.show()
plt.pie(vowels,labels=('Line 1','Line 2','Line 3','Line 4'),autopct='%1.1f%%')
plt.legend(title="Vowels in each line", loc="best")