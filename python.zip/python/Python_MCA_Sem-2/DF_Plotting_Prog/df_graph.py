import matplotlib.pyplot as plt
import pandas as pd

# BAR GRAPH 1
exam_data  = {'name': ['Anastasia', 'Dima', 'Katherine', 'James', 'Emily', 'Michael', 'Matthew', 'Laura', 'Kevin', 'Jonas'],
        'score': [12.5, 9, 16.5, 11, 9, 20, 14.5, 17, 8, 19],
        'attempts': [1, 3, 2, 3, 2, 3, 1, 1, 2, 1],
        'qualify': ['yes', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'no', 'no', 'yes']}

df = pd.DataFrame(exam_data)
x = df['name']
y = df['score']

plt.bar(x,y,label='Exam Data', color='red')
plt.xlabel('Student Name')
plt.ylabel('Exam Score')

plt.title('Bar Graph Demo')

plt.legend()
plt.show()

# BAR GRAPH 2
empSales=[1001,1002,1005,1014,1008,1012]
empProd=[1003,1004,1006,1010,1011,1013]

SalesSal = [10000,23000.50,18000.33,16500.50,12000.75,9999.99]
ProdSal= [5000,6000,4500,12000,9000,10000]

plt.bar(empSales,SalesSal,label='Sales Dept',color='red')
plt.bar(empProd,ProdSal,label='Production Dept',color='green')

plt.xlabel("Employee IDs")
plt.ylabel("Salaries")
plt.title("Departmentwise Employee Salary")
plt.legend()
plt.show()

# HISTOGRAM
emp_age = [22,45,30,59,58,57,56,45,43,43,50,40,34,33,25,19]
bins=[0,10,20,30,40,50,60]

plt.hist(emp_age, bins, histtype='bar', rwidth=0.8, color='cyan')
plt.xlabel('Employee Ages')
plt.ylabel('No. of Employees')
plt.title('Age Group wise No. of Employees')
plt.legend()

plt.show()

slices = [30, 20, 15, 15]
depts = ['Sales', 'Production', 'HR', 'Finance']
colours = ['magenta', 'cyan', 'brown', 'gold']

plt.pie(slices, labels=depts, colors=colours, startangle=90, explode=(0,0.2,0,0.2),shadow=True, autopct='%.2f%%')
plt.title('Department Wise Employees Count')
plt.legend()
plt.show()