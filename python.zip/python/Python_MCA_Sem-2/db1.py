
import sqlite3 as mysqldb

conn = mysqldb.connect('db')

cursor = conn.cursor()
#cursor.execute("drop table contacts")
cursor.execute('''create table if not exists contacts([name] char(20), [contact] number, [bdt] date)''')
conn.commit()
#cursor.execute("delete from contacts")
conn.commit()
#cursor.execute('''Insert into contacts(name, contact, bdt) values
#        ('Asha',9898078789,'12-02-90'),('Heer',909099989,'31-31-99')''')

sql = "insert into contacts(name, contact, bdt) values (?, ?, ?)"
name='Heer'
contact = 909099989
bdt = '31-31-99'
val = (name, contact, bdt)
cursor.execute(sql, val)
#vals = [('Asha',9898078789,'12-02-90'),('Heer',909099989,'31-31-99')]
#cursor.executemany(sql, vals)
conn.commit()
cursor.execute('select * from contacts')

#Method 1: fetchone just to fetch 1 record
'''
row = cursor.fetchone()

while row is not None:
    print(row)
    row = cursor.fetchone()
''' 
#OR Method 2: use the fetchall() to fetch all records at a time

rows = cursor.fetchall()
'''
for row in rows:
    print(row)
'''
# To fetch a specific column:

for row in rows:
    print("Name is ", row[0])
    print("Phone No is ",row[1])
    print("BDT is ",row[2])
cursor.close()
conn.close()

