# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
t1 = ("Orange","Apple","mango","banana")
print(t1)
nm = input("Enter Fruit name =>")

if nm in t1:
    print(nm ," is availbe in tuple")
else:
    print(nm ," is not  availbe in tuple")