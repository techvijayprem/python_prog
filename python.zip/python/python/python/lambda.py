# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# merge two list


t1 = (1,2,3)
t2 = (1,2,3)

print((lambda x,y:x+y)(t1,t2))