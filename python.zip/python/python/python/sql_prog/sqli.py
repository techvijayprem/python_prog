import sqlite3

conn = sqlite3.connect('test.db')
conn.execute(" CREATE TABLE if not exists todo( id integer primary key, task text not null );")

conn = sqlite3.connect('test.db')
cursor = conn.cursor()

cursor.execute("SELECT * FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()

for table in tables:
    print(table[0])



def insertdata(task):
    query = "insert into todo(task) values(?);"
    conn.execute(query,(task,))
    conn.commit()

insertdata("FEEL PAIN ")
insertdata(" KNOW PAIN ")
insertdata(" ACCEPT PAIN")

query = " select * from todo;"
for rows in conn.execute(query):
    print(rows)
    

conn.close()
