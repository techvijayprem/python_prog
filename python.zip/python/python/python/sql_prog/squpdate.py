import sqlite3

conn = sqlite3.connect('test.db')

def updatedata(taskid,newtask):
    query = "update todo set task = ? where id = ?;"
    conn.execute(query,(newtask,taskid))

conn.commit()

updatedata(3,'go to hell')

query = "select * from todo;"
for rows in  conn.execute(query):
    print(rows)


# conn.execute("DROP TABLE TF EXISTS todo")
# conn.commit()
# conn.close()
conn.close()
