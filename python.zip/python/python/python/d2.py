# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:21:25 2024

@author: mcaa230022
"""

nm = "hellow vijay"
n = "l"
xx = nm.rfind(n)
print(xx)
print(xx)
print(nm.find('v'))
print(nm.count("l"))
 


s = "Hello, World! Hello, Python!" 
s1 = "Hello"

index = s.rfind(s1)
print(index)

name = "vijay kya hal"
nm = name.replace("vijay", "abced")
print(nm)

print(name.split(" "))
print(name.rstrip(" "))