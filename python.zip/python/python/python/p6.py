

def  sort_matrix(M):
    sorted_matrix = [sorted(row) for row in M]
    return sorted(sorted_matrix)

M = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
print(M)

sorted_m = sort_matrix(M)
print(sorted_m)


