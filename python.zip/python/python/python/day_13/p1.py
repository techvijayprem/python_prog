# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


import os

'''

cwd = os.getcwd()
print("Current Working Directory =>",cwd)
os.mkdir("D:/test")
print("Directoiry")

'''

os.rmdir("D:/test")
print("Directory Removied")        

