# -*- coding: utf-8 -*-
"""
Created on Wed Mar 27 13:22:40 2024

@author: mcaa230022
"""

import os


'''
fd = "D:/test/tt/vij.txt"
file = open(fd,'w')
file.write("hellow")
file.close()



fd = "D:/test/tt/vij.txt"
file = open(fd,'r')
text = file.read()
print(text)

'''

fd = "D:/test/tt/vij.txt"
os.rename(fd,"D:/test/tt/baby.txt")
print("renaming done")

