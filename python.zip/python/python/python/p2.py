# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 23:33:28 2024

@author: mcaa230022
"""

n1 = int(input("Enter number =>"))
n2 = input("Enter Name =>")
n3 = eval(input("Enter Numbver =>"))

print(n1)
print(type(n1))
print(n2)
print(type(n2))
print(n3)
print(type(n3))


