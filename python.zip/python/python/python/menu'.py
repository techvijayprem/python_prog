import tkinter as tk
from tkinter import Menu

def new_file():
    print("New File")


pt = tk.Tk()
pt.title("Tkinter Application ")

mbar = Menu(pt)
pt.config(menu=mbar)

fmenu = Menu(mbar, tearoff=0)
mbar.add_cascade(label="File", menu=fmenu)
fmenu.add_command(label="New", command= new_file)
fmenu.add_separator()
fmenu.add_command(label="Exit", command=pt.quit)

edit_menu = Menu(mbar, tearoff=0)
mbar.add_cascade(label="Edit", menu=edit_menu)
help_menu = Menu(mbar, tearoff=0)
mbar.add_cascade(label="Help", menu=help_menu)
pt.mainloop()
