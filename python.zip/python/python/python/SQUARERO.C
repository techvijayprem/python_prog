	//find square root number.
#include<stdio.h>
#include<conio.h>

float square_root(float no)
{
	float x=no,a=1;
	float an=0.000001;

	while(x-a>an)
	{
		x=(x+a)/2;
		a=no/x;
	}
	return x;
}

void main()
{
	FILE *fp;
	float no,an;
	clrscr();
	fp=fopen("squareroot.txt","w");
	printf("\n\tenter no==>");
	scanf("%f",&no);
	an=square_root(no);

	printf("\n\tthe no %f of sqaue root is=>%.2f ",no,an);
	fprintf(fp,"the no %f of sqaue root is=>%.2f",no,an);

	getch();
}
