import csv
with open('book2.csv',newline='') as f:
    reader = csv.reader(f)
    datalist = list(reader)

print(datalist)
