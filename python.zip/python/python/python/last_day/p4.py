import matplotlib.pyplot as plt
import numpy as np

# create data points for three plots

x1 = np.array([1,2,3])
y1 = np.array([1,2,3])

x2 = np.array([4,5,6])
y2 = np.array([4,5,6])

x3 = np.array([7,8,9])
y3 = np.array([7,8,9])


plt.plot(x1, y1, label='plot 1')
plt.plot(x2, y2, label='plot 2')
plt.plot(x3, y3, label='plot 3')

plt.xlabel('X-asis')
plt.ylabel('Y-axix')
plt.title('Multiple Plots Examples')
plt.legend()

plt.show()
