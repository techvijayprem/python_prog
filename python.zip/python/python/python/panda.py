import pandas as p

df = p.read_excel("stud.xlsx","Sheet1")
print(df)


df = p.read_csv("stud.csv")
print(df)

d = {'rollno':[1,2,3],
    'name' :['sunil','ganesh','jacob'],
     'age' : [70,60,50]
   }
df = p.DataFrame(d)
print(df)

df = p.read_excel("stud.xlsx","Sheet1")
r,c = df.shape
print("row",r,"column",c)

df = p.read_excel("stud.xlsx","Sheet1")
print(df.tail(2))

df = p.read_excel("stud.xlsx","Sheet1")
print(df[3:8])

df = p.read_excel("stud.xlsx","Sheet1")
print(df[::-1])

df = p.read_excel("stud.xlsx","Sheet1")
print(df.columns)
