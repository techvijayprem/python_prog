# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 00:13:11 2024

@author: mcaa230022
"""

l5 = [1,2,3,4,5]
print(l5)
l5[0] = 88
print(l5)