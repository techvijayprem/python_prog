# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 00:16:51 2024

@author: mcaa230022
"""

lst = ["vijay","leela","shivam","mama"]
print(lst)

name = input("Enter Name U want to search in lisr =>")
x = 0
for name in lst:
   
    print("found",x)
    x = x+1
   
    break
    
    