# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#1 

l1 = [1,7,9,4,5]
print(l1)

#2

print(len(l1))

#3

l1.append(6)
print(l1)

#4

l1.sort()
print(l1)

# range

l1 = range(0,10)
print(l1)
l2 = list(l1)
print(l2)

l5 = [1,2,3,4,5]
print(l5)
l5[0] = 88
print(l5)

for i in l5:
    print(i)
    
    
l5.extend(l1)
print(l5)

l5.reverse()
print(l5)

# sort

l5.sort()
print(l5)
