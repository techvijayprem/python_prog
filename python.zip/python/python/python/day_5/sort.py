# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

l1 = [1,2,3,"vija"]
l1.sort()
print(l1)