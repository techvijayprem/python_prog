# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 00:16:00 2024

@author: mcaa230022
"""

#ls= [1,2,3,4,5,20,4,33,2,'vuis']
#print(ls)
#ls.sort()
#print(ls)

n=[1, 4, 5, 2, 3, 'Suresh', 'Ramesh', 'Arjun']
n.sort()
print(n)
