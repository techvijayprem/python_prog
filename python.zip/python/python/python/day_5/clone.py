# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 00:40:51 2024

@author: mcaa230022
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

l1 = [1,2,3,"vija"]
print(l1)
l2 = l1.copy()
print(l2)