# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 00:10:41 2024

@author: mcaa230022
"""

l1 = [1,7,9,4,5]
print(l1.count(7))