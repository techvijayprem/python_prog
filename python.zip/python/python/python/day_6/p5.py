# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 00:52:58 2024

@author: mcaa230022
"""

#5.	Take an empId from the user and check if that employee

# is there in the dictionary or not.

emp = {1:"vijay",2:"baby",3:"leela",4:"shivm"}
print(emp)
id = int(input("Enter id =>"))

if id in emp:
    
    print("Employee is here")
    
else:
    
    print("Not Availbe")
    
