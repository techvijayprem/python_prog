# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 00:48:22 2024

@author: mcaa230022
"""

emp = {1:"vijay",2:"baby",3:"leela",4:"shivm"}

print(len(emp))

