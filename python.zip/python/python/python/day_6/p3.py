# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 00:51:25 2024

@author: mcaa230022
"""
#3.	Display all empID and make a separate list of just IDs.

emp = {1:"vijay",2:"baby",3:"leela",4:"shivm"}
print(emp.keys())