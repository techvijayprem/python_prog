# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# 1.	Create a dictionary of employees where empId will be the key and value will be the name of an employee

emp = {1:"vijay",2:"baby",3:"leela",4:"shivm"}
print(emp.values())