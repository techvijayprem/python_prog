# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 00:59:52 2024

@author: mcaa230022
"""

# 6.	If an empID is there in the dictionary then display the name of
# that employee or if not available then add an ID and Name of the employe
# in the dictionary

emp = {1:"vijay",2:"baby",3:"leela",4:"shivm"}
print(emp)
 
eid = int(input("Enter id =>"))
  
if eid in emp:
    print("avi")
else:
    print("not availbe ")
    name = input("Enter name")
    emp[eid] = name

print(emp)