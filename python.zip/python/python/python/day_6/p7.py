# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 01:24:22 2024

@author: mcaa230022
"""

#7.	Change the name of the employee of empID taken by the user

emp = {1:"vijay",2:"baby",3:"leela",4:"shivm"}
print(emp)

eid = int(input("Enter Emp id =>"))
name = input("Enter Name")

emp[eid] = name

print(emp)