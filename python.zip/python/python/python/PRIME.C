#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>

typedef enum Bool{false,true}Bool;

Bool isPrime(const int no)
{
	int i;

	if(no == 0 || no == 1)
		return false;

	if(no == 2)
		return true;

	if(no%2 == 0)
		return false;

	for(i=3; i<no/2; i++)
	{
		if(no%i == 0)
			return false;
	}
	return true;
}

Bool noofDigit(int no)
{
	int count = 0;

	while(no>0)
	{
		no = no/10;
		count++;
	}
	return count;
}

int isCircular(int no)
{
	int first_digit,no_of_digit,div,i;

	if(isPrime(no) == false)
		return false;

	no_of_digit = noofDigit(no);

	for(i=2; i<no_of_digit; i++)
	{
		div = pow(10,no_of_digit - 1);
		first_digit = no/div;
		no = no%div;
		no = no*10+first_digit;

		if(isPrime(no) == false)
		return false;
	}
	return true;

}
void main()
{
	FILE *fp;

	int i,ch;


	clrscr();


	do
	{
		printf("\n 1 isolate \n 2 circular \n 3 exit \n ");
		printf("Enter Choice ");
		scanf("%d",&ch);

		switch(ch)
		{
			case 1:
			fp = fopen("iprime.txt","w");
				for(i=2; i<1000; i++)
				{
					if(isPrime(i) == true)
					{
						printf(" %d ",i);
						fprintf(fp," %d\n",i);
					}
				}
				fclose(fp);
			break;

			case 2:
				fp = fopen("icprime.txt","w");
				for(i=2; i<1000; i++)
				{
					if(isCircular(i) == true)
					{
						printf(" %d ",i);
						fprintf(fp," %d\n",i);
					}
				}
				fclose(fp);
			break;

			case 3:
				exit(0);
			break;

		default:
			printf("!! Wrong Choice !!");
		}
	}while(ch>0);

	getch();
}