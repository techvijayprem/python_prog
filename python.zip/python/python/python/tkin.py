import tkinter as tk

pt = tk.Tk()
pt.title("WIDGETS WITH GRID ")
label1 = tk.Label(pt, text="Label 1", padx = 10, pady = 5, bg = "light blue")
button = tk.Button(pt, text="click me", padx=10, pady=5, bg="orange")

label1.grid(row=0, column = 0 )
button.grid(row=2, column = 0, columnspan=2)

pt.mainloop()
