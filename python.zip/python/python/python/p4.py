# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 23:40:08 2024

@author: mcaa230022
"""

stud= [{'name': 'Amit', 'age': 25}, {'name': 'Bina', 'age': 22}, {'name': 'Dax', 'age': 25}]
print(stud)
print("\n\n")
sort_model = sorted(stud, key = lambda x: x['age'])
print(sort_model)