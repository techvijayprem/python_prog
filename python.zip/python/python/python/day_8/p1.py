# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 13:44:16 2024

@author: mcaa230022
"""

def findstr(str2 = "all"):
    cnt = str1.count(str2)
   # print("cnt ",cnt)
    li = []
    print(li)
    index = 0
    for i in range(cnt):
        index = str1.find(str2,index,len(str1))
        li.append(index)
        index += 1
    return li

str1 = "hello all , good morning all"
print(str1)
str2 = input("Enter Name =>")
print(str2)
print(findstr(str2))
    
    