# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


def isprime(n):
    flag = True
    for i in range(2,(n//2)+1):
        if n%i == 0:
            flag = False
            break
    if flag == True:
        print(n)
        return flag
    else: 
        return flag
    
l1 = []

def generateprime(no):
    i = 1
    while i <= no:
        if isprime(i) == True:
            l1.append(i)
            
        i += 1
    print(l1)
    
generateprime(10)        



