import matplotlib.pyplot as plt

x = [1,2,3,2,1]
y = [2,3,2,1,2]

plt.plot(x, y, 'b-')
plt.fill(x, y, 'b', alpha=0.3)

plt.xlabel('X-axix')
plt.ylabel('Y-axix')
plt.title('Diamond shape')

plt.gca().set_aspect('equal', adjustable='box')

plt.show()
