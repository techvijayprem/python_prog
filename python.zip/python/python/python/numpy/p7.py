import matplotlib.pyplot as pyl

import numpy as np

games = np.array(['cricket','football','basketball','kabdii','pubg'])
participants= np.array([23,25,35,63,40])
pyl.pie(participants,labels=games)
pyl.legend(loc='best')
pyl.savefig('piechart.png')
pyl.show()
