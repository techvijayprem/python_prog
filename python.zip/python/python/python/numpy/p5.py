import matplotlib.pyplot as pyl
import pandas as pd
import numpy as np

gadgets = ['mobile','tv','laptop','monitor']
sales = [12,22,10,33]
pyl.bar(gadgets,sales,width=0.3)
pyl.show()

