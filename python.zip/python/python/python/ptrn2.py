# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 22:56:47 2024

@author: mcaa230022
"""

def half(n):
    for i in range(1,n+1):
        for j in range(i,n+1):
            print("* ",end=" ")
        print("\r")
        
n = 5
half(5)