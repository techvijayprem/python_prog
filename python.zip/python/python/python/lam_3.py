# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 00:17:16 2024

@author: mcaa230022
"""

l1 = [1,2,3]
l2 = [4,5,6]
li = list(map(lambda x,y:x*y,l1,l2))
print(li)