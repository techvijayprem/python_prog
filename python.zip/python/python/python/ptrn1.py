# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

def half(n):
    for i in range(1,n+1):
        for j in range(1,i+1):
            print("* ",end=" ")
        print("\r")
        
n = 5
half(5)