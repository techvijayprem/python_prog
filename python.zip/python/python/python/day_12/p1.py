 
 

file = open("s1.txt","w")
l = ("How are you \n","I am fine \n","See you \n")
file.write("Happy Birthday \n" )
file.writelines(l)
file.close()
print("Done:")
 
 
file = open("s1.txt","r+") 
print("OUTPUT of the File")
print(file.read())
print()
file.close()

 
'''


file = open("s1.txt","r+") 
file.seek(0)
print("output of read(10) is :")
print(file.read(30))
print()
file.close()


noofwords = 0
with open("s1.txt","r") as file:
    data = file.read()
    lines = data.split()
    noofwords += len(lines)
    
print(noofwords)


'''


'''


f = open("s1.txt","r")
str = f.read()
lines = str.count("\n")
f.seek(0)
for i in range(lines):
    print("line",(i+1),"->",len(f.readline().split()))
    
f.close()
 
 
'''

