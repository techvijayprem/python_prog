# -*- coding: utf-8 -*-
"""
Created on Sun Mar 31 23:39:22 2024

@author: mcaa230022
"""

emp = ["name => vijay "," Kushwaha "," MCA","ROll No => 22"]
print(emp)