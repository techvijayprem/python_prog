# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 13:56:28 2024

@author: mcaa230022
"""

t1 = ("vijay","raj","kusheha")
t2 = (40,50,50,30,50)

t3 = (t1,t2)
print(t3)


