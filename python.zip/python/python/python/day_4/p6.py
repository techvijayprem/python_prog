# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 14:02:50 2024

@author: mcaa230022
"""

frut = ("mango","orange","apple","banana")
print(frut)
name = input("ENter Fruits name =>")

if(name in frut):
    print(name," Fruits availble in tuple")
else:
    print(name," Fruits availble in tuple")
    