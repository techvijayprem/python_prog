# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 14:06:50 2024

@author: mcaa230022

 

for i in range(5):
    city = input("Enter City name =>")
    st = (city)
    
print(st) 
"""

city1 = input("Enter city 1: ")
city2 = input("Enter city 2: ")
city3 = input("Enter city 3: ")

cities_gujarat = (city1, city2, city3)

print("Cities in Gujarat:", cities_gujarat)

print(len(cities_gujarat))
 