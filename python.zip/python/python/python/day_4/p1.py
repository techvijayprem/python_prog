# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 13:50:14 2024

@author: mcaa230022
"""

first = input("Enter first name")
last = input("Enter last name")
mid = input("Enter middel name")
name = (first ,last , mid)
print(name)