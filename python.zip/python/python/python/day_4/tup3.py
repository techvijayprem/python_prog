# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 13:48:00 2024

@author: mcaa230022
"""

my_tuple = (1, 2, 3, 'apple', 'banana')
print(my_tuple)      
# output: (1, 2, 3, 'apple', 'banana’)

# Assign Values to a Tuple:
# Modifying values in a tuple
my_tuple = my_tuple + (4, 'orange')
print(my_tuple)
# output:  (1, 2, 3, 'apple', 'banana', 4, 'orange