# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 13:32:43 2024

@author: mcaa230022
"""

name = ("hellow","how","have")
print(name)
print(name[1])

lst = [1,2,3,4,5,6]
l = tuple(lst)
print(l)

t = tuple(range(1,10,2))
print(t)

print(l[-1])

# print(l[10])

#slicing 

print(l[::-2])

#loop

for i in l:
    print(i)