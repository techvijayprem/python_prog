# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 14:02:10 2024

@author: mcaa230022
"""

t3 = (10,20,30,40)
no = int( input("Enter num =>"))

if(no in t3):
    print("present")
else:
    print("not in t3")