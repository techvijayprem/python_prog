# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 14:32:42 2024

@author: mcaa230022
"""

#Create a nested tuple t4 of your (name, (hobbies), (friends), degree) by taking user inputs.

name = input("enter name => ")
h1 = input("Enter hobby => ")
h2 = input("Enter hobby => ")
h3 = input("Enter hobby => ")
f1 = input("Enter frd => ")
f2 = input("Enter frd => ")
f3 = input("Enter frd => ")
dg = input("Enter Degree => ")

hob = (h1,h2,h3)
frd = (f1,f2,f3)
t4 = (name,tuple(hob),tuple(frd),dg)

print(t4)

 