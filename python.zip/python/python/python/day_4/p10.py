# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 14:45:38 2024

@author: mcaa230022
"""

t4 = ((1, 2, 3), (4, 5, 6), (7, 8, 9))

element = 6

found = False

for i in range(len(t4)):
    for j in range(len(t4[i])):
        if t4[i][j] == element:
            print("Element found at position:", (i, j))
            found = True
            break

if not found:
    print("Element not found")