# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 14:54:29 2024

@author: mcaa230022
"""

t1 = int(input("Enter nuu =>"))
t2 = int(input("Enter nuu =>"))
t3 = int(input("Enter nuu =>"))
t4 = int(input("Enter nuu =>"))

t5 = (t1,t2,t3,t4)
print(t5)

print(t5[::-1])