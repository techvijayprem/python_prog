# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 13:53:42 2024

@author: mcaa230022
"""

t2 = (20,40,50,60,80)
sum = 0
for i in t2:
    sum = sum + i
    
print(sum)