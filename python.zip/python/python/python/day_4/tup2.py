# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 13:42:16 2024

@author: mcaa230022
"""

t1 = (1,2,3,4,2,2,5)
t2 = (6,7,8,9)
t3 = t1 + t2
print(t3)

print(3*t2)

print(len(t1))
print(t1.count(2))
print(t1[1])

t4 = sorted(t1)
print(t4)

t5 = sorted(t1,reverse = True)
print(t5)