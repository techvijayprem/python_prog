# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 00:08:21 2024

@author: mcaa230022
"""

li = [1,2,3,4]
print(li)
fun = (lambda x,y:x.append(y))
fun(li,6)
print(li)
