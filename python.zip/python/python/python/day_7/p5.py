# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 13:58:09 2024

@author: mcaa230022
"""


def multi(lst):
    m = 1
    for i in lst:
         m = m * i
    return m 
        
    
lst = [1,2,3,4,5]
print(lst)
print("Multi =>",multi(lst))