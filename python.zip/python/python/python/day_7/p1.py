# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 12:24:05 2024

@author: mcaa230022
"""

print("""   1 addition
      2 substratction
      3 multiplication
      4 division""")

ch = int(input("Enter choice =>"))


def add(x,y):
    return x+y

def sub(x,y):
    return x-y

def mul(x,y):
    return x*y

def div(x,y):
    return x/y

if(ch == 1):
    x = int(input("Enter Number 1 =>"))
    y = int(input("Enter Number 2 =>"))
    print("SUM is =>",add(x,y))
    
elif (ch == 2):
    x = int(input("Enter Number 1 =>"))
    y = int(input("Enter Number 2 =>"))
    print("substraction is =>",sub(x,y))
    
elif(ch == 3):
    x = int(input("Enter Number 1 =>"))
    y = int(input("Enter Number 2 =>"))
    print("multiplication is =>",mul(x,y))
    
elif(ch == 4):
    x = int(input("Enter Number 1 =>"))
    y = int(input("Enter Number 2 =>"))
    print("Division is =>",div(x,y))
    
else:
    print("INvalide choice ")
    