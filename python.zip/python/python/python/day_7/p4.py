# -*- coding: utf-8 -*-
"""
Created on Tue Mar 19 13:36:23 2024

@author: mcaa230022
"""

def uni(lst):
    nlst = []
    for ele in lst:
        if ele not in nlst:
            nlst.append(ele)
    return nlst
    
    
    
lst = [1,2,2,3,4,5,5,5,6,6,6,6]
print("Uniqu list",uni(lst))