# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:36:23 2024

@author: mcaa230022
"""

n = 12
print(n)
print(type(n))
m = float(n)
print(m)
print(type(m))

name = input("Enter name =>")
print(name)
print(type(name))
print(float(name))
print(type(name))