# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:54:05 2024

@author: mcaa230022
"""
p = eval(input("ENter Principle rate =>"))
r = eval(input("Rate of Intrest =>"))
n = eval(input("Number of YEar =>"))
SI = p*r*n/100
print("SIPMPLE INTREST =>",SI)