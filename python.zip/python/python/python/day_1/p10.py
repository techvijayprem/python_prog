# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:52:13 2024

@author: mcaa230022
"""

r = eval(input("Enter Radius =>"))
pi = 3.14

aoc = pi*r*r
print("calculate area of circle =>",aoc)