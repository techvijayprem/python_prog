# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:49:13 2024

@author: mcaa230022
"""


name = input("Enter name =>")
print("HELLOW ",name)