# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:34:40 2024

@author: mcaa230022
"""

age = eval(input("Enter Age =>"))
print(age)
print(type(age))