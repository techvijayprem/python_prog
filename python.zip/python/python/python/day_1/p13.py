# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:58:06 2024

@author: mcaa230022
"""

a = 10
b = 20

print(a)
print(b)

a = a+b
b = a-b
a = a-b

print(a)
print(b)