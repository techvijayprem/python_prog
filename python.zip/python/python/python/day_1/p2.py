# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:33:31 2024

@author: mcaa230022
"""

name = input("Enter name =>")
print(name)