# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:41:50 2024

@author: mcaa230022
"""

n = 30
m = 4

rem = n%m
print(rem)