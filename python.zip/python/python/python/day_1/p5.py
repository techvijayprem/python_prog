# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:38:04 2024

@author: mcaa230022
"""

n1 = eval(input("Enter Mark 1 =>"))
n2 = eval(input("Enter Mark 2 =>"))
print("SUM IS =>",n1+n2)
print("SUB IS =>",n1-n2)
print("MUL IS =>",n1*n2)
print("DIV IS =>",n1/n2)