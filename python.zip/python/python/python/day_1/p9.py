# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:50:52 2024

@author: mcaa230022
"""


name = input("Enter name =>")
print(name)
print(name)
print(name)