# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:21:58 2024

@author: mcaa230022
"""

str1 = "Hello!...Good Morning"
print(str1.count("o"))
print(str1.find("g"))

#reverse
str2 ="I like Python Programming"
substr ="Python"
index = str2.find(substr)
reversed_substr = substr[::-1]
result = str2[:index] + reversed_substr + str2[index + len(substr):]
print(result)


#replace
str1= "Hello"
xy=str1.replace("Hello", "hyeee")
print(xy)


#Splits 
name="Hello student welcome to the lj college"
print(name.split(" "))



