# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 23:52:13 2024

@author: mcaa230022
"""

a = 10
b = 20
c = 5

if(a>b) and (a>c):
    print("A is big =>",a)
elif(b>a) and (b>c):
    print("B is big =>",b)
else:
    print("C is big =>",c)
    
if(a<b) and (a<c):
    print("A is MIN =>",a)
elif(b<a) and (b<c):
    print("B is MIN =>",b)
else:
    print("C is MIN =>",c)