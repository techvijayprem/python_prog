# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 23:49:18 2024

@author: mcaa230022
"""

x = eval(input("Enter number =>"))
y = input("Enter Name =>")
z = eval(input("ENter numbner =>"))

print(type(x))
print(type(y))
print(type(z))