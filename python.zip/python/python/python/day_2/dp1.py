# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 23:42:09 2024

@author: mcaa230022
"""

# Python program to convert decimal into other number systems
dec = 344

print("The decimal value of", dec, "is:")
print(bin(dec), "in binary.")
print(oct(dec), "in octal.")
print(hex(dec), "in hexadecimal.")
