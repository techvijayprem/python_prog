# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 00:10:31 2024

@author: mcaa230022
"""

# palindrom

num = int(input("Enter Number =>"))
tmp = num
rev = 0

while(num>0):
    rem = num%10
    rev = rev*10 + rem
    num = num//10
    
if(tmp == rev):
    print("Palindrom")
else:
    print("NOT PALINDROM")
    


 