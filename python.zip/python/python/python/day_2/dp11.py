# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 00:08:03 2024

@author: mcaa230022
"""

num = int(input("Enter Number => "))
if(num<0):
    print(num," NEGETIVE")
elif(num == 0):
    print(num," ZERO")
else:
    print(num," is POSITIVE")
