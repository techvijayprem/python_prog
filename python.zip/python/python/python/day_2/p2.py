# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 23:39:06 2024

@author: mcaa230022
"""

a = int(input("Enter number =>"))
if a%2 == 0:
    print("EVEN NUM =>",a)