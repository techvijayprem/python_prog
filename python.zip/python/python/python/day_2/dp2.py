# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 23:47:05 2024

@author: mcaa230022
"""

bi = int(input("Enter binary num =>"))
oc = float(input("Enter octal num => "))
hx = 