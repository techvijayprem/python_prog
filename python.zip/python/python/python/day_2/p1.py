# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

x = 10
if(x > 5):
    print('Bigger')
else:
    print('smaller')