# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 23:55:51 2024

@author: mcaa230022
"""

n = int(input("Enter Number =>"))
if(n%2 == 0):
    print(n," is EVEN")
else:
    print(n," id ODD")
    