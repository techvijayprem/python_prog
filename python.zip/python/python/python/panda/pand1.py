#change index
'''
import pandas as p
df = p.read_excel("stu.xlsx","Sheet1")
df1 = df.set_index('age')
print(df1)
'''
# modify
'''
import pandas as p
df = p.read_excel("stu.xlsx","Sheet1")
df1 = df.set_index('age',inplace=True)
print(df)

#search
'''
import pandas as p
df = p.read_excel("stu.xlsx","Sheet1")
df1 = df.set_index('age',inplace=True)
print(df.loc[2])
 

