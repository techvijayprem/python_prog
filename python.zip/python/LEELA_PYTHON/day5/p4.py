
l = [0,1,2,3,4,5,6]

print("before : ",l[0])

l[0] = 20

print("after : ",l[0])

print(l)


