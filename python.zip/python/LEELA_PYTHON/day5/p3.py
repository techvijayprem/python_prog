# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 23:56:37 2024

@author: mcaa230042
"""

r = range(0,9)
l = list(r)

print(l)
print(type(l))