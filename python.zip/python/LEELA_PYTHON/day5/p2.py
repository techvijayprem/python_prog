
names = ['leela','vijay','nita']

print(names)
print(type(names))

