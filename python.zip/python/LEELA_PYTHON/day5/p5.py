
l = ['leela','vikas','ritu']

print(l)

print(l[0])
print(l[1])
print(l[2])
print(type(l[1]))
