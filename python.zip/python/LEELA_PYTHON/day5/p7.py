#clone

l1 = [10,2,3,1,5]

print(l1)

l2 = l1.copy()

print(l2)

#sort

l1.sort()

print(l1)