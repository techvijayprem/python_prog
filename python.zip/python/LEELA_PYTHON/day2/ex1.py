# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:10:34 2024

@author: mcaa230042
"""

a = int(input("enter the value : "))
if a%2==0:
    print("even number")
else:
    print("not even")