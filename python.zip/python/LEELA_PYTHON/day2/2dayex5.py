# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 22:41:24 2024

@author: mcaa230042
"""

val1 = eval(input("enter value 1 : "))
val2 = eval(input("enter value 2 : "))

# if val1 == val2 and val1 == val2:
#    print("true...")
    
# else:
#    print("false..")

if val1 < val2 or val1 == val2:
    print("true...")
    
else:
    print("false..")