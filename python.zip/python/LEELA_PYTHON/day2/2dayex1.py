# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:42:42 2024

@author: mcaa230042
"""

num = int(input("enter the number : "))

binary_num = bin(num)
octal_num = oct(num)
hex_num = hex(num)

print("binary number : ",binary_num)
print("octal number : ",octal_num)
print("hexadecimal number : ",hex_num)