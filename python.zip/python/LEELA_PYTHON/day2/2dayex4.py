# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 22:36:40 2024

@author: mcaa230042
"""

#4.	Take 3 different inputs from user and display their data type.

name = input("enter name : ")
val1 = eval(input("enter value 1 : "))
val2 = eval(input("enter value 2 : "))

print(type(name))
print(type(val1))
print(type(val2))