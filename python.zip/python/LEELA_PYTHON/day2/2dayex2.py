# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:47:34 2024

@author: mcaa230042
"""
#2.	Take binary, octal and hexadecimal numbers as an input and convert them to Decimal number
binary = 0b110101
octal = 0o123     
hexa = 0xba2 

print("decimal number of binary : ",int(binary))
print("decimal number of octal : ",int(octal))
print("decimal number of hexadecimal : ",int(hexa))