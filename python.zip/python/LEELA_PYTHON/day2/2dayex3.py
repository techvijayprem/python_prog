# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 22:33:22 2024

@author: mcaa230042
"""
#3.	Without applying condition statement display output as “true” if the 1st number greater than the 2nd number and “false” if 2nd number is larger than the 1st one.
num1 = 30
num2 = 20

print("true" if num1 > num2 else "false")