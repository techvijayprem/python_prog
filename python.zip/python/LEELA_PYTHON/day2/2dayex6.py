# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 22:51:31 2024

@author: mcaa230042
"""

val1 = eval(input("enter value 1 : "))
val2 = eval(input("enter value 2 : "))

result  = val1 ^ val2

print(result)