#8.	Take an input character from the user and check whether that character is present in the above given string or not. – Using ‘in’ operator and using ‘not in’ operator

str1 = "programming"
str2 = "programming"

#if str1 in str2:
#    print(" the cracter in str1")
#else:
#    print(" the cracter not in str1")

if str1 not in str2:
    print(" the cracter in str1")
else:
    print(" the cracter not in str1")