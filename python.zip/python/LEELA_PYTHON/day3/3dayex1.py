# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:57:47 2024

@author: mcaa230042
"""

print("python programming\nit is good")