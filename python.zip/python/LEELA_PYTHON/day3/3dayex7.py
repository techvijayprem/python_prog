# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 00:47:24 2024

@author: mcaa230042
"""

num = eval(input("enter number : "))
name = input("enter string : ")

print(3*name)