# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 00:44:46 2024

@author: mcaa230042
"""

str1 = input("enter str1 : ")
str2 = input("enter str2 : ")

print(str1 + str2)