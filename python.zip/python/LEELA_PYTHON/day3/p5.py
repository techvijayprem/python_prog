# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 13:59:40 2024

@author: mcaa230042
"""

#menu driven


def find_length(s):
    return len(s)

def uppercase(s):
    return s.upper()

def lowercase(s):
    return s.lower()

def capitalize(s):
    return s.capitalize()

def split_string(s):
    return s.split()

while True:
    print("\nString Manipulation Program")
    print("1. Find the length of a string")
    print("2. Print the string in upper case")
    print("3. Print the string in lower case")
    print("4. Print the string with initial capital")
    print("5. Split the string")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == '1':
        string = input("Enter a string: ")
        print("Length of the string:", find_length(string))
    elif choice == '2':
        string = input("Enter a string: ")
        print("String in upper case:", uppercase(string))
    elif choice == '3':
        string = input("Enter a string: ")
        print("String in lower case:", lowercase(string))
    elif choice == '4':
        string = input("Enter a string: ")
        print("String with initial capital:", capitalize(string))
    elif choice == '5':
        string = input("Enter a string: ")
        print("Split string:", split_string(string))
    elif choice == '6':
        print("Exiting program...")
        break
    else:
        print("Invalid choice. Please try again.")def find_length(s):
            return len(s)

        def uppercase(s):
            return s.upper()

        def lowercase(s):
            return s.lower()

        def capitalize(s):
            return s.capitalize()

        def split_string(s):
            return s.split()

        while True:
            print("\nString Manipulation Program")
            print("1. Find the length of a string")
            print("2. Print the string in upper case")
            print("3. Print the string in lower case")
            print("4. Print the string with initial capital")
            print("5. Split the string")
            print("6. Exit")

            choice = input("Enter your choice: ")

            if choice == '1':
                string = input("Enter a string: ")
                print("Length of the string:", find_length(string))
            elif choice == '2':
                string = input("Enter a string: ")
                print("String in upper case:", uppercase(string))
            elif choice == '3':
                string = input("Enter a string: ")
                print("String in lower case:", lowercase(string))
            elif choice == '4':
                string = input("Enter a string: ")
                print("String with initial capital:", capitalize(string))
            elif choice == '5':
                string = input("Enter a string: ")
                print("Split string:", split_string(string))
            elif choice == '6':
                print("Exiting program...")
                break
            else:
                print("Invalid choice. Please try again.")