# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 00:12:48 2024

@author: mcaa230042
"""

name = "python programming very much"

print(name[-5:])