# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:16:48 2024

@author: mcaa230042
"""

str1 = "Leela rathodoooo"


print(str1.count('e'))
print(str1.find('a'))
print(str1.rfind('a'))
print(str1.index('o'))
print(str1.rindex('o'))
#print(str1.lower('L'))
print(str1.replace('L','i'))
print(str1.split(" "))
