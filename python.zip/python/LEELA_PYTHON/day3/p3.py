# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:09:02 2024

@author: mcaa230042
"""

str1 = "leela"
str2 = "rathod"

print(str1 + str2)

print(3*str1)
print(2*".hello.")

