# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:07:40 2024

@author: mcaa230042
"""

str1 = "python java"

print('a' in str1)
print('z' in str1)