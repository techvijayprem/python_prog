# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 00:19:28 2024

@author: mcaa230042
"""

name = "leelaeee"

print(name[::-1])
