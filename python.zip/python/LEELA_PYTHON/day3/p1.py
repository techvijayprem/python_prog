# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 23:00:58 2024

@author: mcaa230042
"""

str1 = "hello..leela..good..morning"

print(str1[0])
print(str1[4:])
print(str1[3:10:1])
print(str1[-1])
print(str1[-5:])


