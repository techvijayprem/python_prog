# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 00:13:45 2024

@author: mcaa230042
"""

name = "python programming\nit is good"

print(name[19:29])


