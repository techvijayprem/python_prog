'''
5.	Write a Python function to multiply all the numbers in a list.
'''

def multilist(l1):
    m=1
    for i in l1:
        m = m*i
    return m

l1 = [1,2,3,4,5,6]

print(l1)

print("multiply of list : ",multilist(l1) )
        
