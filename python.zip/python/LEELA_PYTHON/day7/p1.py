'''
1.	Take user input and create a menu driven program to perform mathematical
 operations like addition, subtraction, multiplication, division, integer division,
 power. Return values from the functions
'''

print("""..1. addition..
         ..2. subtraction..
         ..3. multiplication..
         ..4. division..
         ..5. power..""")
         
ch = eval(input("enter choice : "))


def add(a,b):
    return a+b

def sub(a,b):
    return a-b

def mul(a,b):
    return a*b

def div(a,b):
    return a/b

def power(a,b):
    return a**b

if ch==1:
    print("sum is => ",add(10,2))
    
elif ch==2:
    print("subtraction is =>",sub(10,2))
    
elif ch==3:
    print("multipilication is =>",mul(10,2))
    
elif ch==4:
    print("division is => ",div(10,2))
    
elif ch==5:
    print("power is => ",power(10,2))
    
else:
    print("not valid")



    