'''
4.	Write an UDF to return a list having only unique values by removing duplicate 
values from the provided input list.
Eg. I/P:  Sample List : [1,2,3,3,3,3,4,5]      O/P:   Unique List : [1, 2, 3, 4, 5]
'''

def uni(l1):
    l2 = []
    for val in l1:
        if val not in l2:
            l2.append(val)
    return l2
    
l1 = [1,2,3,4,5,5,6,6,6,9]

print("unique list is = ",uni(l1))
    

