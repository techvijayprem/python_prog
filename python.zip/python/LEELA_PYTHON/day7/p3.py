# 3.	Create functions to convert decimal numbers to binary, octal and hexadecimal
# numbers. Always return values from the functions.

def dtb(a):
    return bin(a)

def dto(a):
    return oct(a)

def dth(a):
    return hex(a)

a = eval(input("enter decimal value a : "))

print("decimal numbers to binary : ",dtb(a))

print("decimal numbers to octal : ",dto(a))

print("decimal numbers to hexadecimal : ",dth(a))



