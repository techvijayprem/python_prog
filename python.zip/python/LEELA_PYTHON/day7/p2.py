'''
2.	Create functions to calculate 
a.	Area of a rectangle = width * length
b.	Area of a triangle = ½ * Height * Base
c.	Area of a circle = pi*r*r
'''

def aor(width,lenth):
    return width * lenth

def aot(height,base):
    return 0.5*height*base

def aoc(radius):
    return 3.14*radius*radius

print("Area of a rectangle = ",aor(12,10))

print("Area of a triangle = ",aot(10,5))

print("Area of a circle = ",aoc(12))

    

