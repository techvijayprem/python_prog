
#4.	Display all employee names and take them to a separate list


employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees.values())