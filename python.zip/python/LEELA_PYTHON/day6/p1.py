#1.	Create a dictionary of employees where empId will be the key and value 
#will be the name of an employee

employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees)
