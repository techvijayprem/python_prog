#  

employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees)

id = int(input("enter id = "))

if id in employees:
    
    print("id is there ",employees.values())
else:
    print("id is not so add the id and name :")
    name = input("enter name : ")
    employees[id] = name
            
    print(employees)
