#3.	Display all empID and make a separate list of just IDs.


employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees.keys())

