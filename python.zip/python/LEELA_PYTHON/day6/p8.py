#8.	Remove an employee whose ID is provided by the user

employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees)

empid = eval(input("enter id : "))

employees.pop(empid)

print(employees)

