#5.	Take an empId from the user and check if that employee is there
# in the dictionary or not.


employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees)

id = int(input("enter id = "))

if id in employees:
    print("id is there ",id)
else:
    print("id is not ",id)


