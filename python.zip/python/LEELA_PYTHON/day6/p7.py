#7.	Change the name of the employee of empID taken by the user

employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(employees)

empid = eval(input("enter id : "))
name = input("enter name : ")

employees[empid] = name

print(employees)



