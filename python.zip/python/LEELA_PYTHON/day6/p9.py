#9.	Take 5 names of students as an input from the user and create a dictionary 
#with keys as their initials and value is a list as [age, degree, favorite subject] 

name1  = input("enter 1 name : ")

name2  = input("enter 2 name : ")

name3  = input("enter 3 name : ")

name4  = input("enter 4 name : ")

name5  = input("enter 5 name : ")

