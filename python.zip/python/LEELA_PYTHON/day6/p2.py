# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 00:50:07 2024

@author: mcaa230042
"""
#2.	Display how many employees are there in the dictionary.

employees = {1:'leela',2:'vijay',3:'baby',4:'shivam'}
 
print(len(employees))