# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 12:36:42 2024

@author: mcaa230042
"""

a  = 10
b = 10

c  = a<<2
d = a>>2
e = a & b
f = a | b
g = ~a
h = a ^ b

print(a)
print(c)
print(d)
print(e)
print(f)
print(g)
print(h)



 
 