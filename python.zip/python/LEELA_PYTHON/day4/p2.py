# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 13:05:08 2024

@author: mcaa230042
"""

str1 = "programming"
str2 = "programming"

if str1 in str2:
    print(" the cracter in str1")
else:
    print(" the cracter not in str1")