# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 13:25:55 2024

@author: mcaa230042
"""

a = 1010
b = 1100
 

c = a & b
d = a | b
e = a ^ b
print(bin(c))
print(bin(d))
print(bin(e))
