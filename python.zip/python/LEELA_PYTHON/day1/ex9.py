# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 11:39:01 2024

@author: mcaa230042
"""
input_string = input("string is : ")

print(input_string  *3)