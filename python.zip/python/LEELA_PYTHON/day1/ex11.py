# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 11:52:02 2024

@author: mcaa230042
"""

p = eval(input("principle amount is : "))
r = eval(input("rate of interest is : "))
n = eval(input("no of year : "))

si = (p*r*n)/100
print("principle amount is : ")
print("rate of interest is : ")
print("no of year : ")
print("simple Interest is : ",si)
