# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:17:01 2024

@author: mcaa230042
"""

#14.	WAP to convert the given temperature from Fahrenheit to Celsius using the formula C = (F – 32) / 1.8

f = int(input(" Fahrenheit is : "))

ftoc = (f-32)/1.8

print(" Fahrenheit is",f)
print("fahrenheit to clesius is : ",ftoc)