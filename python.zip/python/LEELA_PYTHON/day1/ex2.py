# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:34:11 2024

@author: mcaa230042
"""

name = input("name is :")
print(name)