# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:53:30 2024

@author: mcaa230042
"""

print("leela")

m1 = eval(input("m1 is : " ))
m2 = eval(input("m2 is : "))

sum=m1+m2
sub=m1-m2
mul=m1*m2
div=m1/m2
rem=m1%m2

print("sum is :",sum)
print("sub is :",sub)
print("mul is :",mul)
print("div is :",div)
print("rem is :",rem)