# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 15:06:25 2024

@author: mcaa230042
"""

a=10
b=3

c=a/b
d=a%b

print("divison is :",c)
print("remender is :",d)
