# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:38:42 2024

@author: mcaa230042
"""

age = eval(input("age is : "))
print(age)