# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:40:38 2024

@author: mcaa230042
"""

value = input("value is : ")

print(value)

print(float(value))


