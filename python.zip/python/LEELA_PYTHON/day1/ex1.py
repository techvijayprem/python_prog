# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 14:31:11 2024

@author: mcaa230042
"""

print("hello world")
