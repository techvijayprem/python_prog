# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:05:44 2024

@author: mcaa230042
"""

l = eval(input("length is : "))
b = eval(input("width is : "))


aot = (l*b)/2
print("length is : ")
print("width is : ")
print("area of triangle is : ",aot)
