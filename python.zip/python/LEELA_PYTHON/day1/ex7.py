# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 15:08:25 2024

@author: mcaa230042
"""

name = input("name is : ")
age = eval(input("age is : "))
add = input("address is : ")

print("Biodata")
print("name is : ",name)
print("age is : ",age)
print("address is : ",add)