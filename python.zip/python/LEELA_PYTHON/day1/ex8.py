# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 11:26:34 2024

@author: mcaa230042
"""

name = input("name is : ")

print("Hello......",name)