# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 11:44:13 2024

@author: mcaa230042
"""

pi = 3.14
r = 4
aoc = pi*r*r
print("area of circle : ",aoc)